# Portable Installed Control Plane

Read control-plane/README.md first. Canonical agents, prompts and skills live under
.github; control-plane/framework owns shared policy and runtime. Claude adapters
carry no independent authority. Adopt the bound persona before governed work.
Lifecycle, admission, start, review and completion require explicit command invocation.
Installation creates no horizon, project Canon, approved work, forge setup or admission.
Preserve user changes. Do not commit, push or change product files without authorization.
Activate .cp-venv before framework commands. Keep credentials and local state out of Git.
