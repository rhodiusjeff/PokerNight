#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
PLANNING_TEST_PUBLICATION=1 bash "$SCRIPT_DIR/planning-admission.test.sh"
python3 - "$SCRIPT_DIR" <<'PY'
import contextlib
import copy
import importlib.util
import pathlib
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

script_directory = pathlib.Path(sys.argv.pop())
spec = importlib.util.spec_from_file_location("publication", script_directory / "planning-publication.py")
publication = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publication)


class PublicationReviewRegressions(unittest.TestCase):
	def setUp(self):
		temporary = tempfile.TemporaryDirectory()
		self.addCleanup(temporary.cleanup)
		self.root = pathlib.Path(temporary.name).resolve()
		self.evidence = publication.evidence
		self.capture = publication.capture
		self.contract = publication.contract
		self.git = publication.planning_git.git
		self.authority = {"actor": "Fixture Operator", "authority": "fixture only", "date": "2026-09-29",
			"rationale": "Bounded review regression", "evidence": "fixture://review-fix"}
		self.base = self.contract.empty_specification()
		self.base_path = self.root / publication.admission.SPECIFICATION_PATH
		self.execution_path = self.root / publication.admission.EXECUTION_PATH
		for filename, value in ((self.base_path, self.base), (self.execution_path, {"phases": {}, "contracts": {}})):
			filename.parent.mkdir(parents=True, exist_ok=True)
			filename.write_bytes(self.evidence.encoded(value))
		self.git(self.root, "init", "--quiet", "-b", "integration")
		self.git(self.root, "config", "user.name", "Local Fixture")
		self.git(self.root, "config", "user.email", "fixture@example.invalid")
		self.git(self.root, "add", "--", publication.admission.SPECIFICATION_PATH, publication.admission.EXECUTION_PATH)
		self.git(self.root, "commit", "--quiet", "-m", "Local fixture baseline")
		self.target = publication.planning_git.resolve_commit(self.root, "refs/heads/integration")
		self.git(self.root, "switch", "--quiet", "-c", "planning")

	def context_offer(self, suffix):
		identity = "ADHOC-" + suffix * 32
		source = self.root / (suffix + ".txt")
		source.write_bytes(b"Exact local fixture source")
		self.capture.create_capture(SimpleNamespace(root=self.root, id=identity, confirmed=True, sources=[source],
			kind="ad-hoc", origin_phase=None, origin_specification=None, title="Fixture", author="Fixture Author"))
		filename = self.capture.resolve_document(self.root, identity)
		document = self.capture.read_capture(filename)
		canon = {"kind": "requirement", "text": "Fixture requirement", "status": "active", "sources": ["source-1"]}
		content = copy.deepcopy(self.base["content"])
		content["canon"]["REQ-1"] = canon
		document["proposal"] = {"schema": "cp-plan-proposal-v1", "id": identity, "revision": 1,
			"author": "Fixture Author", "base_revision": 0, "base_digest": self.base["content_digest"],
			"sources": document["sources"], "changes": [{"collection": "canon", "id": "REQ-1", "operation": "add",
			"before_digest": None, "value": canon}], "result": content, "execution_expectations": {}}
		review_id = self.evidence.record_review(document, "review-1", self.evidence.subject(document), b"Independent fixture report",
			[], {**self.authority, "actor": "Independent Fixture Reviewer", "scope": "Complete fixture", "independent": True}, True)
		fields = {"kind": "approval", "actor": self.authority["actor"], "authority": self.authority["authority"],
			"date": self.authority["date"], "scope": "Complete fixture", "checklist": dict.fromkeys(self.contract.CHECK_NAMES, True),
			"integration_assessment": "Fixture only", "dag_assessment": "Empty DAG", "findings_acknowledged": [],
			"conditions": [], "signoff": "Synthetic fixture signoff", "invocation_source": "operator-confirmation"}
		digest = self.evidence.draft_decision(document, "decision-1", [review_id], fields)
		decision = document["workflow"]["decision"]["drafts"][0]["decision"]
		self.evidence.finalize_decision(document, "decision-1", digest,
			{**self.authority, "decision_digest": self.contract.digest(decision)}, True)
		filename.write_text(self.capture.render(document))
		bundle = publication.admission.prepare(self.root, identity, "decision-1", self.base_path, self.execution_path,
			self.evidence.retain(filename.read_bytes())["sha256"], True)["bundle"]
		return publication.offer(self.root, bundle, "refs/heads/integration")

	def create(self, offered, identity):
		result = publication.create_attempt(self.root, offered, identity,
			{**self.authority, "offer_digest": offered["offer_digest"]}, True)
		self.assertTrue(result["events"])
		self.assertEqual(result["events"][0]["state"], "prepared")
		return result

	def snapshot(self):
		return {str(filename.relative_to(self.root)): filename.read_bytes()
			for filename in (self.root / "control-plane").rglob("*") if filename.is_file()}

	def test_cross_context_attempt_reuse_does_not_create_claim(self):
		owner = self.context_offer("a")
		other = self.context_offer("b")
		self.create(owner, "owned-attempt")
		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "immutable publication record differs"):
			self.create(other, "owned-attempt")
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(self.create(other, "other-attempt")["state"], "prepared")

	def test_cross_context_reuse_preserves_withdrawn_claim(self):
		owner = self.context_offer("a")
		other = self.context_offer("b")
		self.create(owner, "owned-attempt")
		self.create(other, "other-attempt")
		publication.withdraw(self.root, "other-attempt", self.authority, True)
		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "immutable publication record differs"):
			self.create(other, "owned-attempt")
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(self.create(other, "fresh-attempt")["state"], "prepared")

	def test_withdrawn_attempt_reuse_does_not_replace_newer_claim(self):
		offered = self.context_offer("a")
		for identity in ("old-attempt", "newer-attempt"):
			self.create(offered, identity)
			publication.withdraw(self.root, identity, self.authority, True)
		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "withdrawn"):
			self.create(offered, "old-attempt")
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(self.create(offered, "fresh-attempt")["state"], "prepared")

	def test_close_after_real_local_integration_returns_existing_revision(self):
		offered = self.context_offer("a")
		self.create(offered, "integrated-attempt")
		result = publication.resume(self.root, "integrated-attempt", True)
		directory = publication.attempt_directory(self.root, "integrated-attempt")
		self.git(self.root, "fetch", "--quiet", "--no-tags", "--no-write-fetch-head", str(directory / "repository"),
			"refs/heads/cp-admission/integrated-attempt")
		self.git(self.root, "update-ref", "refs/heads/integration", result["commit"], self.target)
		before = self.snapshot()
		for retry in range(2):
			observed = publication.close_request(self.root, "integrated-attempt", self.authority, True)
			self.assertEqual(observed["state"], "already-applied")
			self.assertEqual(observed["revision"], 1)
			self.assertEqual(observed["target_commit"], result["commit"])
			self.assertFalse(observed["live_admission"])
			self.assertEqual(self.snapshot(), before)
		self.assertIsNone(publication.MockTransport(self.root, directory).closed())
		self.assertNotIn("closed-unmerged", [event["state"] for event in publication.journal(self.root, directory)])

	def test_dedicated_withdrawal_reenables_evidence_mutation(self):
		offered = self.context_offer("a")
		self.create(offered, "authorized-attempt")
		publication.resume(self.root, "authorized-attempt", True)
		identity = offered["offer"]["context_id"]
		filename = self.capture.resolve_document(self.root, identity)

		def update(document):
			self.evidence.record_round(document, "SCRUB", "after-withdrawal", "Fixture report", [],
				"Fixture Reviewer", "2026-09-29")
			return document

		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "withdrawal"):
			self.evidence.mutate(self.root, identity, self.evidence.retain(filename.read_bytes())["sha256"], update, True)
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(publication.withdraw(self.root, "authorized-attempt", self.authority, True)["state"], "withdrawn")
		result = self.evidence.mutate(self.root, identity, self.evidence.retain(filename.read_bytes())["sha256"], update, True)
		self.assertTrue(result["updated"])
		self.assertEqual(self.capture.read_capture(filename)["workflow"]["admission"]["status"], "withdrawn")


class TransferPublicationGuards(unittest.TestCase):
	def setUp(self):
		temporary = tempfile.TemporaryDirectory()
		self.addCleanup(temporary.cleanup)
		self.root = pathlib.Path(temporary.name).resolve()
		self.document = {"id": "H008", "context": {"state": "planning", "transfers": [{"publication": "local-only/incomplete"}]}}

	def test_offer_checks_current_survivor_before_returning_offer(self):
		with mock.patch.object(publication.planning_git, "repository_root", return_value=self.root), \
			 mock.patch.object(publication.planning_git, "git"), \
			 mock.patch.object(publication.planning_git, "resolve_commit", return_value="a" * 40), \
			 mock.patch.object(publication.planning_git, "blob_json", return_value={}), \
			 mock.patch.object(publication.admission, "validate_bundle", return_value={}), \
			 mock.patch.object(publication.admission, "verify_directory", return_value=({}, self.document, {}, {})), \
			 mock.patch.object(publication.evidence, "read_document", return_value=(self.root / "capture.md", self.document)):
			with self.assertRaisesRegex(ValueError, "transfer publication incomplete"):
				publication.offer(self.root, self.root / "bundle", "refs/heads/integration")

	def test_fresh_refuses_retired_source_before_candidate_work(self):
		self.document["context"] = {"state": "absorbed"}
		with mock.patch.object(publication.evidence, "read_document", return_value=(self.root / "capture.md", self.document)):
			with self.assertRaisesRegex(ValueError, "retired transfer source"):
				publication.fresh(self.root, {"offer": {"context_id": "H008"}})

	def test_resume_refuses_survivor_before_integration_observation(self):
		header = {"offer": {"context_id": "H008"}}
		with mock.patch.object(publication, "load_attempt", return_value=(self.root, self.root, header)), \
			 mock.patch.object(publication, "attempt_lock", return_value=contextlib.nullcontext()), \
			 mock.patch.object(publication, "journal", return_value=[]), \
			 mock.patch.object(publication.evidence, "read_document", return_value=(self.root / "capture.md", self.document)), \
			 mock.patch.object(publication, "integrated_observation") as integrated:
			with self.assertRaisesRegex(ValueError, "transfer publication incomplete"):
				publication.resume(self.root, "old-attempt", True)
			integrated.assert_not_called()


unittest.main(verbosity=2)
PY