#!/usr/bin/env python3
"""Read commit-pinned operational contracts; live execution remains disabled."""

import argparse
import importlib.util
import json
import pathlib
import subprocess
import sys

sys.dont_write_bytecode = True


def module(name):
    location = pathlib.Path(__file__).with_name(name + ".py")
    spec = importlib.util.spec_from_file_location(name.replace("-", "_"), location)
    loaded = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(loaded)
    return loaded


contract = module("planning-contract")
SPECIFICATION = "control-plane/operational/SPECIFICATION.json"
EXECUTION = "control-plane/state/execution.json"
CONFIG = "control-plane/state/operational-context.json"
INSTANCE = "control-plane/state/CONTROL_PLANE_STATE.json"
LIVE_BLOCKER = "live execution enforcement is deferred; operational --require-executable is disabled"
COMPLETE = {"done", "merged"}


class PhaseNotFound(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise ValueError(message)


def local_path(root, relative):
    root = pathlib.Path(root).resolve()
    candidate = root / relative
    require(candidate.is_relative_to(root), "path escapes repository")
    for component in (candidate, *candidate.parents):
        if component == root:
            break
        require(not component.is_symlink(), f"symlink is not allowed: {component}")
    return candidate


def git(root, *arguments):
    result = subprocess.run(["git", "--no-replace-objects", "-C", str(root), *arguments],
                            capture_output=True, text=True)
    require(result.returncode == 0, f"Git read failed: {result.stderr.strip()}")
    return result.stdout.strip()


def target_commit(root, target_ref):
    require(isinstance(target_ref, str) and
            target_ref.startswith(("refs/heads/", "refs/remotes/")),
            "target_ref must be a full refs/heads/... or refs/remotes/... ref")
    git(root, "check-ref-format", target_ref)
    return git(root, "rev-parse", "--verify", target_ref + "^{commit}")


def strict_json(text):
    def unique(pairs):
        result = {}
        for key, value in pairs:
            require(key not in result, f"duplicate JSON key: {key}")
            result[key] = value
        return result

    def nonfinite(value):
        raise ValueError(f"nonfinite JSON number: {value}")

    return json.loads(text, object_pairs_hook=unique, parse_constant=nonfinite)


def committed_specification(root, commit):
    entry = git(root, "ls-tree", commit, "--", SPECIFICATION)
    require(entry.startswith(("100644 blob ", "100755 blob ")),
            "selected target has no regular operational SPECIFICATION.json")
    specification = strict_json(git(root, "show", f"{commit}:{SPECIFICATION}"))
    contract.validate_specification(specification)
    return specification


def selected_target(root, target_ref=None):
    if target_ref is not None:
        return target_ref
    config_path = local_path(root, CONFIG)
    require(config_path.is_file(), "missing operational-context.json; explicitly configure --target-ref with --confirmed")
    config = contract.load_json(config_path)
    contract.validate_shape(config, contract.object_schema({
        "schema": {"const": "cp-operational-context-v1"}, "target_ref": contract.TEXT,
    }), "operational context")
    return config["target_ref"]


def validate_execution(specification, execution):
    contract.validate_shape(execution, contract.EXECUTION, "execution state")
    for digest, content in execution["contracts"].items():
        contract.validate_content(content)
        require(contract.digest(content) == digest, "retained contract digest mismatch")
    for identity, binding in execution["phases"].items():
        revision = binding["specification_revision"]
        require(1 <= revision <= specification["revision"], f"phase {identity}: stale execution revision")
        digest = binding["contract_digest"]
        require(specification["admissions"][revision - 1]["content_digest"] == digest,
                f"phase {identity}: retained binding differs from target admission history")
        content = execution["contracts"].get(digest)
        require(content is not None, f"phase {identity}: original bound contract is missing")
        require(identity in specification["content"]["phases"], f"phase {identity}: absent from target specification")
        require(content["phases"].get(identity, {}).get("status") == "active",
                f"phase {identity}: retained contract does not govern phase")


def resolve(root, phase_id, require_executable=False, target_ref=None,
            expected_target_commit=None, expected_specification_digest=None,
            expected_execution_digest=None, include_archive=False):
    root = pathlib.Path(root).resolve()
    require(not (require_executable and include_archive),
            "--include-archive cannot be used with --require-executable")
    target_ref = selected_target(root, target_ref)
    commit = target_commit(root, target_ref)
    require(expected_target_commit is None or expected_target_commit == commit, "stale target commit")
    specification = committed_specification(root, commit)
    require(expected_specification_digest is None or
            expected_specification_digest == specification["content_digest"], "stale specification evidence")
    if phase_id not in specification["content"]["phases"]:
        raise PhaseNotFound(f"phase {phase_id!r} was not found in operational specification")
    legacy_matches = module("resolve-horizon").candidates(root, phase_id, include_archive)
    require(not legacy_matches, f"phase {phase_id!r} ownership is ambiguous: operational and legacy horizon")
    execution = contract.load_json(local_path(root, EXECUTION))
    validate_execution(specification, execution)
    execution_digest = contract.digest(execution)
    require(expected_execution_digest is None or expected_execution_digest == execution_digest,
            "stale execution evidence")
    instance = contract.load_json(local_path(root, INSTANCE))
    binding = execution["phases"].get(phase_id)
    status = binding["status"] if binding else "not-started"
    retained = binding is not None and status != "not-started"
    content = execution["contracts"][binding["contract_digest"]] if retained else specification["content"]
    phase = content["phases"][phase_id]
    dependencies = [edge["from"] for edge in content["dag"]["edges"] if edge["to"] == phase_id]
    dependency_statuses = {identity: execution["phases"].get(identity, {}).get("status", "not-started")
                           for identity in dependencies}
    require(target_commit(root, target_ref) == commit, "target moved during resolution; retry with fresh evidence")
    result = {
        "source": "operational", "horizon": None, "packet_name": None, "packet": None,
        "tracker": None, "archive": None, "ledgers": None,
        "specification": SPECIFICATION, "execution": EXECUTION, "state": INSTANCE,
        "status_path": EXECUTION, "config": CONFIG,
        "phases": "control-plane/operational/phases", "work": "control-plane/operational/phases",
        "timing": "control-plane/state/timing", "target_ref": target_ref, "target_commit": commit,
        "operational_revision": specification["revision"], "operational_digest": specification["content_digest"],
        "execution_digest": execution_digest, "instance_state": instance.get("state"),
        "phase_id": phase_id, "phase_status": status, "phase_contract": phase,
        "contract_source": "retained-bound" if retained else "current",
        "contract_revision": binding["specification_revision"] if retained else specification["revision"],
        "contract_digest": contract.digest(content), "contract_content": content,
        "dependencies": dependencies, "dependency_statuses": dependency_statuses,
        "blocked_dependencies": [identity for identity in dependencies if dependency_statuses[identity] not in COMPLETE],
        "executable": False, "live_admission": False, "execution_blocker": LIVE_BLOCKER,
    }
    if require_executable:
        require(instance.get("state") == "operational",
                f"control-plane instance is {instance.get('state')!r}, expected 'operational'")
        raise ValueError(LIVE_BLOCKER)
    return result


def check_start_prerequisites(root, phase_id, **options):
    result = resolve(root, phase_id, **options)
    require(result["instance_state"] == "operational", "start prerequisites require an operational instance")
    require(result["phase_status"] == "not-started", "phase has already started; original binding must be preserved")
    require(result["phase_contract"]["status"] == "active", "phase is obsolete")
    require(not result["blocked_dependencies"], f"incomplete dependencies: {result['blocked_dependencies']}")
    return {**result, "prerequisites_satisfied": True}


def write_new(filename, value):
    filename.parent.mkdir(parents=True, exist_ok=True)
    with filename.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False, allow_nan=False)
        stream.write("\n")


def initialize(root, confirmed=False):
    require(confirmed is True, "initialization requires explicit --confirmed")
    paths = [local_path(root, relative) for relative in (SPECIFICATION, EXECUTION)]
    require(not any(filename.exists() for filename in paths),
            "initialization requires both specification and execution absent; no overwrite or migration")
    values = [contract.empty_specification(), {"phases": {}, "contracts": {}}]
    created = []
    try:
        for filename, value in zip(paths, values):
            write_new(filename, value)
            created.append(filename)
    except OSError:
        for filename in created:
            filename.unlink()
        raise
    return {"initialized": [SPECIFICATION, EXECUTION], "executable": False, "live_admission": False}


def configure(root, target_ref, confirmed=False):
    require(confirmed is True, "configuration requires explicit --confirmed")
    commit = target_commit(root, target_ref)
    filename = local_path(root, CONFIG)
    value = {"schema": "cp-operational-context-v1", "target_ref": target_ref}
    if filename.exists():
        require(contract.load_json(filename) == value, "existing configuration differs; replacement is not supported")
    else:
        write_new(filename, value)
    return {"config": CONFIG, "target_ref": target_ref, "observed_target_commit": commit,
            "executable": False, "live_admission": False}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=pathlib.Path, default=pathlib.Path.cwd())
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("init").add_argument("--confirmed", action="store_true")
    configure_parser = commands.add_parser("configure")
    configure_parser.add_argument("--target-ref", required=True)
    configure_parser.add_argument("--confirmed", action="store_true")
    for name in ("resolve", "check-start"):
        reader = commands.add_parser(name)
        reader.add_argument("phase_id")
        reader.add_argument("--target-ref")
        reader.add_argument("--expected-target-commit")
        reader.add_argument("--expected-specification-digest")
        reader.add_argument("--expected-execution-digest")
        reader.add_argument("--require-executable", action="store_true")
        reader.add_argument("--field")
    args = parser.parse_args()
    try:
        if args.command == "init":
            result = initialize(args.root, args.confirmed)
        elif args.command == "configure":
            result = configure(args.root, args.target_ref, args.confirmed)
        else:
            action = resolve if args.command == "resolve" else check_start_prerequisites
            result = action(args.root, args.phase_id, target_ref=args.target_ref,
                            expected_target_commit=args.expected_target_commit,
                            expected_specification_digest=args.expected_specification_digest,
                            expected_execution_digest=args.expected_execution_digest,
                            require_executable=args.require_executable)
        if getattr(args, "field", None):
            require(args.field in result, f"unknown field {args.field!r}")
            value = result[args.field]
            print(value if isinstance(value, str) else json.dumps(value))
        else:
            print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
        return 0
    except (OSError, ValueError) as error:
        print(f"Error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())