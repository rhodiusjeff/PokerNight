#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
export PYTHONDONTWRITEBYTECODE=1
python3 - "$SCRIPT_DIR" <<'PY'
import copy
import importlib.util
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

script_dir = pathlib.Path(sys.argv[1])
loader = importlib.util.spec_from_file_location("execution", script_dir / "planning-execution.py")
execution = importlib.util.module_from_spec(loader)
loader.loader.exec_module(execution)
contract = execution.contract


class ExecutionFixtures(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix="cp-v081-execution-fixture-")
        self.addCleanup(self.temporary.cleanup)
        self.root = pathlib.Path(self.temporary.name).resolve()
        self.git("init", "-q", "-b", "integration")
        self.git("config", "user.name", "Fixture")
        self.git("config", "user.email", "fixture@example.invalid")
        self.content = {
            "canon": {"R1": {"kind": "requirement", "text": "Fixture requirement", "status": "active", "sources": ["fixture"]}},
            "phases": {identity: {"title": identity, "specification": "Original " + identity, "status": "active",
                                   "canon_ids": ["R1"], "acceptance": ["Fixture acceptance"]}
                       for identity in ("CP-101", "CP-102", "CP-101a")},
            "dag": {"order": ["CP-101", "CP-102", "CP-101a"],
                    "edges": [{"from": "CP-101", "to": "CP-102", "type": "requires"}]},
        }
        self.content["phases"]["CP-101a"]["family"] = "CP-101"
        self.specification = self.spec(self.content)
        self.write(execution.SPECIFICATION, self.specification)
        self.git("add", execution.SPECIFICATION)
        self.git("commit", "-qm", "Fixture operational specification")
        self.commit = self.git("rev-parse", "HEAD")
        self.ref = "refs/remotes/origin/integration"
        self.git("update-ref", self.ref, self.commit)
        self.write(execution.EXECUTION, {"phases": {}, "contracts": {}})
        self.write(execution.INSTANCE, {"state": "operational"})
        execution.configure(self.root, self.ref, confirmed=True)

    def git(self, *arguments):
        return subprocess.run(["git", "-C", str(self.root), *arguments], check=True,
                              capture_output=True, text=True).stdout.strip()

    def write(self, relative, value):
        filename = self.root / relative
        filename.parent.mkdir(parents=True, exist_ok=True)
        filename.write_text(json.dumps(value), encoding="utf-8")

    def spec(self, content, previous=None):
        revision = previous["revision"] + 1 if previous else 1
        history = copy.deepcopy(previous["admissions"]) if previous else []
        digest = contract.digest(content)
        history.append({"proposal_id": f"fixture-{revision}", "proposal_revision": 1,
                        "subject_digest": "a" * 64, "decision_digest": "b" * 64,
                        "revision": revision, "content_digest": digest})
        return {"schema": "cp-operational-specification-v1", "revision": revision,
                "previous_revision": revision - 1, "content": copy.deepcopy(content),
                "content_digest": digest, "admissions": history}

    def bind_fixture(self, status="in-progress", identity="CP-101"):
        digest = self.specification["content_digest"]
        value = {"phases": {identity: {"status": status, "contract_digest": digest, "specification_revision": 1}},
                 "contracts": {digest: copy.deepcopy(self.content)}}
        self.write(execution.EXECUTION, value)
        return value

    def amend(self):
        changed = copy.deepcopy(self.content)
        changed["phases"]["CP-101"]["specification"] = "Amended parent"
        changed["canon"]["R1"]["text"] = "Amended requirement"
        changed["dag"]["edges"] = []
        amended = self.spec(changed, self.specification)
        self.write(execution.SPECIFICATION, amended)
        self.git("add", execution.SPECIFICATION)
        self.git("commit", "-qm", "Fixture amendment")
        return self.git("rev-parse", "HEAD")

    def snapshot(self):
        return {str(filename.relative_to(self.root)): filename.read_bytes()
                for filename in self.root.rglob("*") if filename.is_file() and ".git" not in filename.parts}

    def test_remote_target_not_dirty_or_local_head(self):
        self.amend()
        self.write(execution.SPECIFICATION, {"dirty": "not authoritative"})
        result = execution.resolve(self.root, "CP-101")
        self.assertEqual(result["target_commit"], self.commit)
        self.assertEqual(result["phase_contract"]["specification"], "Original CP-101")
        self.assertFalse(result["executable"])

    def test_no_horizon_and_honest_paths(self):
        result = execution.resolve(self.root, "CP-101")
        self.assertFalse((self.root / "control-plane/horizons").exists())
        self.assertEqual(result["source"], "operational")
        for key in ("horizon", "packet", "tracker", "archive", "ledgers"):
            self.assertIsNone(result[key])
        self.assertEqual(result["execution"], execution.EXECUTION)
        self.assertEqual(result["timing"], "control-plane/state/timing")

    def test_dependency_prerequisites_and_family_not_an_edge(self):
        with self.assertRaisesRegex(ValueError, "incomplete dependencies"):
            execution.check_start_prerequisites(self.root, "CP-102")
        family = execution.check_start_prerequisites(self.root, "CP-101a")
        self.assertEqual(family["dependencies"], [])
        self.assertFalse(family["executable"])
        for status in ("closed", "in-review"):
            self.bind_fixture(status)
            with self.assertRaisesRegex(ValueError, "incomplete dependencies"):
                execution.check_start_prerequisites(self.root, "CP-102")
        for status in ("done", "merged"):
            self.bind_fixture(status)
            self.assertTrue(execution.check_start_prerequisites(self.root, "CP-102")["prerequisites_satisfied"])

    def test_retained_binding_after_amendment(self):
        amended_commit = self.amend()
        self.git("update-ref", self.ref, amended_commit)
        for status in ("in-progress", "closed", "in-review", "done", "merged"):
            self.bind_fixture(status, "CP-102")
            result = execution.resolve(self.root, "CP-102")
            self.assertEqual(result["contract_source"], "retained-bound")
            self.assertEqual(result["contract_content"], self.content)
            self.assertEqual(result["dependencies"], ["CP-101"])
            self.assertEqual(result["contract_revision"], 1)
            self.assertEqual(result["operational_revision"], 2)
            self.assertEqual(result["phase_status"], status)
            with self.assertRaisesRegex(ValueError, "already started"):
                execution.check_start_prerequisites(self.root, "CP-102")
        self.bind_fixture("in-progress", "CP-101")
        parent = execution.resolve(self.root, "CP-101")
        self.assertEqual(parent["phase_contract"]["specification"], "Original CP-101")
        self.assertEqual(parent["contract_content"], self.content)

    def test_current_unstarted_contract_after_amendment(self):
        self.bind_fixture("not-started")
        self.git("update-ref", self.ref, self.amend())
        result = execution.resolve(self.root, "CP-101")
        self.assertEqual(result["phase_contract"]["specification"], "Amended parent")
        self.assertEqual(result["contract_source"], "current")

    def test_newly_admitted_family_only_blocked_by_actual_edge(self):
        self.bind_fixture()
        changed = copy.deepcopy(self.content)
        changed["phases"]["CP-101b"] = {**changed["phases"]["CP-101a"], "title": "New fixture family"}
        changed["dag"]["order"].append("CP-101b")
        amended = self.spec(changed, self.specification)
        self.write(execution.SPECIFICATION, amended)
        self.git("add", execution.SPECIFICATION)
        self.git("commit", "-qm", "Fixture new family")
        self.git("update-ref", self.ref, self.git("rev-parse", "HEAD"))
        result = execution.check_start_prerequisites(self.root, "CP-101b")
        self.assertEqual(result["dependencies"], [])
        self.assertEqual(execution.resolve(self.root, "CP-101")["contract_revision"], 1)
        changed["dag"]["edges"].append({"from": "CP-101", "to": "CP-101b", "type": "requires"})
        self.write(execution.SPECIFICATION, self.spec(changed, amended))
        self.git("add", execution.SPECIFICATION)
        self.git("commit", "-qm", "Fixture real family dependency")
        self.git("update-ref", self.ref, self.git("rev-parse", "HEAD"))
        with self.assertRaisesRegex(ValueError, "incomplete dependencies"):
            execution.check_start_prerequisites(self.root, "CP-101b")

    def test_stale_target_and_evidence(self):
        for options, message in (({"expected_target_commit": "0" * 40}, "stale target"),
                                 ({"expected_specification_digest": "0" * 64}, "stale specification"),
                                 ({"expected_execution_digest": "0" * 64}, "stale execution")):
            with self.assertRaisesRegex(ValueError, message):
                execution.resolve(self.root, "CP-101", **options)

    def test_single_commit_and_moved_target(self):
        amended_commit = self.amend()
        original_git = execution.git
        reads = []

        def moving_git(root, *arguments):
            if arguments[0] == "show":
                reads.append(arguments[1])
                self.git("update-ref", self.ref, amended_commit)
            return original_git(root, *arguments)

        with patch.object(execution, "git", moving_git):
            with self.assertRaisesRegex(ValueError, "target moved"):
                execution.resolve(self.root, "CP-101")
        self.assertEqual(reads, [f"{self.commit}:{execution.SPECIFICATION}"])

    def test_missing_config_explicit_target_and_unsafe_refs(self):
        (self.root / execution.CONFIG).unlink()
        with self.assertRaisesRegex(ValueError, "missing operational-context"):
            execution.resolve(self.root, "CP-101")
        self.assertEqual(execution.resolve(self.root, "CP-101", target_ref=self.ref)["target_commit"], self.commit)
        for ref in ("origin/integration", "HEAD", "refs/tags/tag", "refs/heads/../evil", "refs/heads/main:path",
                    "refs/heads/main^{commit}", "refs/heads/main\n", "--help"):
            with self.assertRaises(ValueError):
                execution.resolve(self.root, "CP-101", target_ref=ref)

    def test_live_execution_and_nonoperational_instance_refused(self):
        with self.assertRaisesRegex(ValueError, "live execution enforcement is deferred"):
            execution.resolve(self.root, "CP-101", require_executable=True)
        for state in ("upgrading", "suspended", "ops-work"):
            self.write(execution.INSTANCE, {"state": state})
            self.assertEqual(execution.resolve(self.root, "CP-101")["instance_state"], state)
            with self.assertRaisesRegex(ValueError, "expected 'operational'"):
                execution.resolve(self.root, "CP-101", require_executable=True)
            with self.assertRaisesRegex(ValueError, "operational instance"):
                execution.check_start_prerequisites(self.root, "CP-101")

    def test_collision_with_real_legacy_owner(self):
        self.write("control-plane/horizons/H000-legacy/TRACKER.json", {"nodes": [{"id": "CP-101"}]})
        with self.assertRaisesRegex(ValueError, "ambiguous"):
            execution.resolve(self.root, "CP-101")

    def test_resolver_hook_cli_and_timing_fail_closed(self):
        resolver = script_dir / "resolve-horizon.py"
        command = [sys.executable, str(resolver), "CP-101", "--root", str(self.root)]
        before = self.snapshot()
        result = subprocess.run(command, capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(result.stdout)["source"], "operational")
        result = subprocess.run([*command, "--field", "timing"], capture_output=True, text=True, check=True)
        self.assertEqual(result.stdout.strip(), "control-plane/state/timing")
        result = subprocess.run([*command, "--field", "horizon"], capture_output=True, text=True, check=True)
        self.assertEqual(result.stdout.strip(), "null")
        result = subprocess.run([*command, "--field", "timing", "--require-executable"], capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertEqual(result.stdout, "")
        self.assertIn("live execution enforcement is deferred", result.stderr)
        self.assertEqual(self.snapshot(), before)
        self.write("control-plane/horizons/H000-legacy/TRACKER.json", {"nodes": [{"id": "CP-101"}]})
        result = subprocess.run(command, capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("ambiguous", result.stderr)

    def test_resolver_missing_config_and_explicit_target(self):
        resolver = execution.module("resolve-horizon")
        (self.root / execution.CONFIG).unlink()
        with self.assertRaisesRegex(ValueError, "missing operational-context"):
            resolver.resolve(self.root, "CP-101", require_executable=True)
        result = resolver.resolve(self.root, "CP-101", target_ref=self.ref)
        self.assertEqual(result["target_commit"], self.commit)
        (self.root / execution.CONFIG).symlink_to(self.root / "missing-config")
        with self.assertRaisesRegex(ValueError, "symlink"):
            resolver.resolve(self.root, "CP-101", require_executable=True)

    def test_review_unit_resolution_unchanged_with_operational_config(self):
        packet = "control-plane/horizons/H000-legacy"
        self.write(packet + "/HORIZON_STATE.json", {"horizon": "H000"})
        self.write(packet + "/ledgers/REVIEW_UNIT_LEDGER.json",
                   {"entries": [{"review_unit_id": "RU-101", "status": "Reserved", "phase_ids": "CP-101"}]})
        result = execution.module("resolve-horizon").resolve_review_unit(self.root, "RU-101")
        self.assertEqual(result["horizon"], "H000")
        self.assertEqual(result["timing"], packet + "/timing")

    def test_bad_binding_and_claimed_status_refused(self):
        value = self.bind_fixture()
        value["phases"]["CP-101"]["status"] = "claimed"
        self.write(execution.EXECUTION, value)
        with self.assertRaises(ValueError):
            execution.resolve(self.root, "CP-101")
        value = self.bind_fixture()
        value["phases"]["CP-101"]["specification_revision"] = 2
        self.write(execution.EXECUTION, value)
        with self.assertRaisesRegex(ValueError, "stale execution revision"):
            execution.resolve(self.root, "CP-101")
        value = self.bind_fixture()
        digest = value["phases"]["CP-101"]["contract_digest"]
        value["contracts"][digest]["phases"]["CP-101"]["specification"] = "tampered"
        self.write(execution.EXECUTION, value)
        with self.assertRaisesRegex(ValueError, "digest mismatch"):
            execution.resolve(self.root, "CP-101")

    def test_self_consistent_binding_must_match_target_history(self):
        value = self.bind_fixture()
        content = copy.deepcopy(self.content)
        content["phases"]["CP-101"]["specification"] = "Self-consistent but never integrated"
        digest = contract.digest(content)
        value["phases"]["CP-101"]["contract_digest"] = digest
        value["contracts"] = {digest: content}
        self.write(execution.EXECUTION, value)
        with self.assertRaisesRegex(ValueError, "differs from target admission history"):
            execution.resolve(self.root, "CP-101")
        value = self.bind_fixture()
        value["contracts"] = {}
        self.write(execution.EXECUTION, value)
        with self.assertRaisesRegex(ValueError, "original bound contract is missing"):
            execution.resolve(self.root, "CP-101")

    def test_partial_initialization_and_symlinks_refuse_without_mutation(self):
        (self.root / execution.EXECUTION).unlink()
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, "both specification and execution absent"):
            execution.initialize(self.root, confirmed=True)
        self.assertEqual(self.snapshot(), before)
        filename = self.root / execution.EXECUTION
        filename.symlink_to(self.root / execution.CONFIG)
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, "symlink"):
            execution.resolve(self.root, "CP-101")
        self.assertEqual(self.snapshot(), before)

    def test_absent_committed_spec_and_invalid_committed_json(self):
        (self.root / execution.SPECIFICATION).unlink()
        self.git("add", execution.SPECIFICATION)
        self.git("commit", "-qm", "Fixture absent spec")
        self.git("update-ref", self.ref, self.git("rev-parse", "HEAD"))
        self.write(execution.SPECIFICATION, self.specification)
        with self.assertRaisesRegex(ValueError, "no regular operational"):
            execution.resolve(self.root, "CP-101")
        (self.root / execution.SPECIFICATION).write_text('{"revision": 1, "revision": 2}')
        self.git("add", execution.SPECIFICATION)
        self.git("commit", "-qm", "Fixture duplicate keys")
        self.git("update-ref", self.ref, self.git("rev-parse", "HEAD"))
        with self.assertRaisesRegex(ValueError, "duplicate JSON key"):
            execution.resolve(self.root, "CP-101")

    def test_execution_cli_read_and_failure_are_nonmutating(self):
        command = [sys.executable, str(script_dir / "planning-execution.py"), "--root", str(self.root)]
        before = self.snapshot()
        result = subprocess.run([*command, "resolve", "CP-101", "--field", "phase_contract"],
                                capture_output=True, text=True, check=True)
        self.assertEqual(json.loads(result.stdout), self.content["phases"]["CP-101"])
        for arguments in (("init",), ("configure", "--target-ref", self.ref),
                          ("resolve", "CP-101", "--require-executable"), ("check-start", "CP-102")):
            result = subprocess.run([*command, *arguments], capture_output=True, text=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(result.stdout, "")
        self.assertEqual(self.snapshot(), before)

    def test_reads_and_refusals_do_not_mutate(self):
        before = self.snapshot()
        execution.resolve(self.root, "CP-101")
        execution.check_start_prerequisites(self.root, "CP-101a")
        with self.assertRaises(ValueError):
            execution.resolve(self.root, "CP-101", require_executable=True)
        with self.assertRaises(ValueError):
            execution.initialize(self.root, confirmed=True)
        with self.assertRaises(ValueError):
            execution.configure(self.root, "refs/heads/integration", confirmed=True)
        self.assertEqual(self.snapshot(), before)

    def test_confirmed_initialization_only_absent_and_configure(self):
        (self.root / execution.SPECIFICATION).unlink()
        (self.root / execution.EXECUTION).unlink()
        (self.root / execution.CONFIG).unlink()
        before = self.snapshot()
        with self.assertRaisesRegex(ValueError, "explicit --confirmed"):
            execution.initialize(self.root)
        with self.assertRaisesRegex(ValueError, "explicit --confirmed"):
            execution.configure(self.root, self.ref)
        self.assertEqual(self.snapshot(), before)
        execution.initialize(self.root, confirmed=True)
        self.assertEqual(contract.load_json(self.root / execution.SPECIFICATION), contract.empty_specification())
        self.assertEqual(contract.load_json(self.root / execution.EXECUTION), {"phases": {}, "contracts": {}})
        execution.configure(self.root, self.ref, confirmed=True)
        execution.configure(self.root, self.ref, confirmed=True)
        with self.assertRaisesRegex(ValueError, "no overwrite"):
            execution.initialize(self.root, confirmed=True)


print("E5 fixture evidence only; no live enforcement or product execution", flush=True)
unittest.main(argv=["planning-execution-fixtures"], verbosity=2)
PY