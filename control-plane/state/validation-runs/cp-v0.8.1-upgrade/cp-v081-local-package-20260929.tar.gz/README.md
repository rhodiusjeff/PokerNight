# Fresh Local Framework Lift

This is a byte-manifested snapshot of an installed framework, not a certified release.
No source-project decisions, horizons, execution state or active upgrade are installed.
Inherited framework docs may describe historical projects/procedures; those examples
are not this project's requirements. Current canonical prompts govern their boundaries.

Runtime: macOS/Linux, Python 3.10+ with venv, Bash, Git for local Git fixtures, and the
packages in control-plane/framework/requirements.txt. Some suites additionally require
PowerShell (pwsh); unavailable tools must be reported, not counted as passing coverage.
Prepare .cp-venv and dependencies separately from this offline installer. It never calls
the network, creates Git history, initializes a horizon, or authorizes execution.
Copilot/Claude, diagram providers, credentials and hosted forge setup are external.

Verify before local use:
    python3 control-plane/framework/scripts/planning-install.py verify --target <this-root>
Run selected suites with planning-validation.py run --help. Output must be separate from
shared timing/progress. Green fixtures are not live forge, real-agent or power-loss evidence.
After operator-directed setup, use canonical command help to select the planning workflow.
No upstream installer/verify.py is present or required by this installed-tree utility.
