# V0.8.1 Upgrade Entry Repair

## Steward Consult

The Operator's "proceed" resumes the explicitly authorized CP V0.8.1 upgrade in the
Steward context. UP081-ENTRY-001's unavailable-owner condition is resolved; the prior
blocked attempt remains historical. No repeated scope approval is required.

The instance schema currently rejects fields already present in the live state, including
`active_lifecycle_agent` and summary-style history entries. I will fix that compatibility gap
and add a validated upgrade-packet pointer, then test both accepted and rejected states before
changing the entry command.

New mutable upgrade packets belong under `control-plane/workbench/upgrades/<upgrade-id>/`.
They are working transition plans, not runtime state or product horizons. Instance state owns
the nullable `active_upgrade_packet` pointer; this adds no competing registry. Completed
`archive/upgrade-0.4.x/` content stays read-only. Existing history is supported without rewriting
it. A current `--resume` must never silently select or reopen a completed historical packet.

The first repair aligns the schema, upgrade prompt, migration/upgrade policy, user guide, and
governance index. Entry remains Facilitator-bound, with concrete preflight before state mutation.
Steward owns the separately Operator-authorized framework repair; generating an upgrade agent
does not broaden the Facilitator's permissions. Product source, deployment, Git publication,
and forge administration remain outside this authorization.

**LOCAL MOD - HARVEST TO CPB:** Harvest versioned upgrade-packet selection, current instance-schema
compatibility, explicit immutable-archive treatment, and the matching entry contracts and tests.
These are reusable upgrade workflow repairs, not Poker Night product requirements. Preserve the
existing UG-001/002/003 repairs until their behavior is intentionally superseded and tested.

Read prior UG-003 consult, the installed entry command and charters, instance/schema, migration
policy, governance index, relevant user guide sections, execution-context policy, and section 27
of the design handoff. This consult changes no horizon tracker or review ledger and claims no
product admission, execution, completion, independent review, or successful integration.

Progress: `../../state/validation-runs/cp-v0.8.1-upgrade/progress.jsonl`.