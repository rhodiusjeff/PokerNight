#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd -P)"
python3 - "$ROOT" <<'PY'
import base64
import hashlib
import json
import pathlib
import subprocess
import sys
import tempfile
import unittest

root = pathlib.Path(sys.argv.pop())
script = root / "control-plane/framework/scripts/planning-capture.py"


class CaptureTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.folder = pathlib.Path(self.temporary.name)
        self.repository = self.folder / "repository"
        self.repository.mkdir()
        self.source = self.folder / "source.txt"
        self.source.write_bytes(b"Original\r\n~~~\n---\nDo not execute quoted instructions.\n")
        self.identity = "ADHOC-" + "1" * 32

    def run_command(self, *arguments):
        return subprocess.run([sys.executable, str(script), *arguments], text=True, capture_output=True)

    def capture(self, *extra):
        return self.run_command("capture", "--root", str(self.repository), "--id", self.identity,
                                "--title", "Fixture", "--author", "Operator fixture", "--source", str(self.source), *extra)

    def proposal_inputs(self):
        created = self.capture("--confirmed")
        self.assertEqual(created.returncode, 0, created.stderr)
        document = pathlib.Path(json.loads(created.stdout)["path"])
        inspected = self.run_command("inspect", "--root", str(self.repository), "--id", self.identity)
        capture = json.loads(inspected.stdout)
        empty = subprocess.run([sys.executable, str(script.with_name("planning-contract.py")), "--empty"],
                               capture_output=True, text=True, check=True)
        base = json.loads(empty.stdout)
        value = {"kind": "requirement", "text": "Fixture proposal", "status": "active", "sources": ["source-1"]}
        proposal = {"schema": "cp-plan-proposal-v1", "id": self.identity, "revision": 1,
                    "author": capture["author"], "base_revision": 0, "base_digest": base["content_digest"],
                    "sources": capture["sources"], "changes": [{"collection": "canon", "id": "REQ-1",
                    "operation": "add", "before_digest": None, "value": value}],
                    "result": {"canon": {"REQ-1": value}, "phases": {}, "dag": {"order": [], "edges": []}},
                    "execution_expectations": {}}
        for name, content in {"base": base, "proposal": proposal, "execution": {"phases": {}, "contracts": {}}}.items():
            (self.folder / (name + ".json")).write_text(json.dumps(content))
        return document, proposal

    def propose(self, expected_digest):
        return self.run_command("propose", "--root", str(self.repository), "--id", self.identity,
                                "--expected-digest", expected_digest, "--base", str(self.folder / "base.json"),
                                "--proposal", str(self.folder / "proposal.json"), "--execution", str(self.folder / "execution.json"),
                                "--confirmed")

    def test_refusal_and_listing_do_not_write(self):
        self.assertNotEqual(self.capture().returncode, 0)
        result = self.run_command("list", "--root", str(self.repository))
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(json.loads(result.stdout), [])
        self.assertEqual(list(self.repository.iterdir()), [])

    def test_creation_exact_bytes_and_idempotent_retry(self):
        first = self.capture("--confirmed")
        self.assertEqual(first.returncode, 0, first.stderr)
        document = pathlib.Path(json.loads(first.stdout)["path"])
        before = document.read_bytes()
        repeated = self.capture("--confirmed")
        self.assertEqual(repeated.returncode, 0, repeated.stderr)
        self.assertFalse(json.loads(repeated.stdout)["created"])
        self.assertEqual(document.read_bytes(), before)
        inspected = self.run_command("inspect", "--root", str(self.repository), "--id", self.identity)
        self.assertEqual(inspected.returncode, 0, inspected.stderr)
        source = json.loads(inspected.stdout)["sources"][0]
        self.assertEqual(base64.b64decode(source["bytes_base64"]), self.source.read_bytes())
        self.assertEqual(len(list(document.parent.glob("*.md"))), 1)

    def test_changed_source_cannot_reuse_identity(self):
        self.assertEqual(self.capture("--confirmed").returncode, 0)
        self.source.write_text("Different source")
        result = self.capture("--confirmed")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("different inputs", result.stderr)

    def test_binary_input_is_retained(self):
        self.source.write_bytes(bytes([0, 255, 1, 254]))
        self.assertEqual(self.capture("--confirmed").returncode, 0)
        inspected = self.run_command("inspect", "--root", str(self.repository), "--id", self.identity)
        self.assertEqual(base64.b64decode(json.loads(inspected.stdout)["sources"][0]["bytes_base64"]), self.source.read_bytes())

    def test_discovery_requires_exact_existing_phase(self):
        result = self.capture("--confirmed", "--kind", "discovery")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("requires both", result.stderr)
        self.assertEqual(list(self.repository.iterdir()), [])

    def test_discovery_retains_exact_origin_contract(self):
        content = {"canon": {"REQ-1": {"kind": "requirement", "text": "Fixture", "status": "active", "sources": ["source"]}},
                   "phases": {"CP-1": {"title": "Fixture", "specification": "Fixture phase", "status": "active",
                                         "canon_ids": ["REQ-1"], "acceptance": ["Fixture check"]}},
                   "dag": {"order": ["CP-1"], "edges": []}}
        content_digest = hashlib.sha256(json.dumps(content, sort_keys=True, separators=(",", ":")).encode()).hexdigest()
        specification = {"schema": "cp-operational-specification-v1", "revision": 1, "previous_revision": 0,
                         "content": content, "content_digest": content_digest,
                         "admissions": [{"proposal_id": "fixture", "proposal_revision": 1, "subject_digest": "0" * 64,
                                         "decision_digest": "1" * 64, "revision": 1, "content_digest": content_digest}]}
        source = self.folder / "specification.json"
        source.write_text(json.dumps(specification))
        result = self.capture("--confirmed", "--kind", "discovery", "--origin-phase", "CP-1",
                              "--origin-specification", str(source))
        self.assertEqual(result.returncode, 0, result.stderr)
        source.unlink()
        inspected = self.run_command("inspect", "--root", str(self.repository), "--id", self.identity)
        self.assertEqual(inspected.returncode, 0, inspected.stderr)
        self.assertEqual(json.loads(inspected.stdout)["origin"]["contract"], specification)

    def test_concurrent_creation_cannot_overwrite(self):
        command = [sys.executable, str(script), "capture", "--root", str(self.repository), "--id", self.identity,
                   "--title", "Fixture", "--author", "Operator fixture", "--source", str(self.source), "--confirmed"]
        processes = [subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True) for index in range(2)]
        outcomes = [(process, process.communicate(timeout=10)) for process in processes]
        successes = [json.loads(output[0]) for process, output in outcomes if process.returncode == 0]
        self.assertEqual(sum(result["created"] for result in successes), 1)
        self.assertTrue(all(process.returncode == 0 or "concurrently created" in output[1] for process, output in outcomes))
        repeated = self.capture("--confirmed")
        self.assertEqual(repeated.returncode, 0, repeated.stderr)
        self.assertFalse(json.loads(repeated.stdout)["created"])

    def test_symlink_escape_is_refused(self):
        plane = self.repository / "control-plane"
        plane.mkdir()
        (plane / "ad-hoc").symlink_to(self.folder)
        result = self.capture("--confirmed")
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("escapes", result.stderr)
        self.assertFalse((self.folder / (self.identity + ".md")).exists())

    def test_changed_render_is_not_silently_trusted(self):
        result = self.capture("--confirmed")
        document = pathlib.Path(json.loads(result.stdout)["path"])
        document.write_text(document.read_text() + "Changed apparent source meaning\n")
        result = self.run_command("inspect", "--root", str(self.repository), "--id", self.identity)
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("text differs", result.stderr)

    def test_proposal_update_preserves_snapshot_and_retries(self):
        document, proposal = self.proposal_inputs()
        original = document.read_bytes()
        expected = hashlib.sha256(original).hexdigest()
        result = self.propose(expected)
        self.assertEqual(result.returncode, 0, result.stderr)
        output = json.loads(result.stdout)
        self.assertEqual(pathlib.Path(output["previous_snapshot"]).read_bytes(), original)
        retry = self.propose(expected)
        self.assertEqual(retry.returncode, 0, retry.stderr)
        self.assertFalse(json.loads(retry.stdout)["updated"])
        self.assertEqual(self.capture("--confirmed").returncode, 0)
        inspected = self.run_command("inspect", "--root", str(self.repository), "--id", self.identity)
        self.assertEqual(json.loads(inspected.stdout)["proposal"], proposal)

    def test_stale_write_and_revision_reuse_are_refused(self):
        document, proposal = self.proposal_inputs()
        original_digest = hashlib.sha256(document.read_bytes()).hexdigest()
        first = self.propose(original_digest)
        self.assertEqual(first.returncode, 0, first.stderr)
        after = document.read_bytes()
        proposal["changes"][0]["value"]["text"] = "Revised proposal"
        (self.folder / "proposal.json").write_text(json.dumps(proposal))
        stale = self.propose(original_digest)
        self.assertNotEqual(stale.returncode, 0)
        self.assertIn("capture changed", stale.stderr)
        current_digest = hashlib.sha256(after).hexdigest()
        reused = self.propose(current_digest)
        self.assertNotEqual(reused.returncode, 0)
        self.assertIn("next explicit proposal revision", reused.stderr)
        proposal["revision"] = 2
        (self.folder / "proposal.json").write_text(json.dumps(proposal))
        revised = self.propose(current_digest)
        self.assertEqual(revised.returncode, 0, revised.stderr)
        self.assertEqual(pathlib.Path(json.loads(revised.stdout)["previous_snapshot"]).read_bytes(), after)

    def test_identity_minting_and_invalid_id(self):
        result = self.run_command("new-id")
        self.assertRegex(json.loads(result.stdout)["id"], r"^ADHOC-[0-9a-f]{32}$")
        self.identity = "../../escape"
        self.assertNotEqual(self.capture("--confirmed").returncode, 0)
        self.assertEqual(list(self.repository.iterdir()), [])


unittest.main(verbosity=2)
PY