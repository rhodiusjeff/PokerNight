#!/usr/bin/env python3
"""Create or inspect local planning captures; never admit, schedule, or publish work."""

import argparse
import base64
import fcntl
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import sys
import tempfile
import uuid
from datetime import datetime, timezone
from contextlib import contextmanager


module_spec = importlib.util.spec_from_file_location("planning_contract", pathlib.Path(__file__).with_name("planning-contract.py"))
contract = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(contract)
IDENTITY = re.compile(r"ADHOC-[0-9a-f]{32}\Z")


def capture_root(root):
    root = root.resolve()
    home = root / "control-plane/ad-hoc"
    contract.require(home.resolve().is_relative_to(root), "capture home escapes the repository")
    return home


def capture_path(root, identity):
    contract.require(bool(IDENTITY.fullmatch(identity)), "invalid capture identity")
    home = capture_root(root)
    target = home / f"{identity}.md"
    contract.require(not target.is_symlink(), "capture entry must not be a symlink")
    return target


def canonical_source(filename, index):
    content = filename.read_bytes()
    return {"id": f"source-{index}", "origin": str(filename),
            "sha256": hashlib.sha256(content).hexdigest(),
            "bytes_base64": base64.b64encode(content).decode("ascii")}


def sync_directory(directory):
    descriptor = os.open(directory, os.O_RDONLY | os.O_DIRECTORY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def publish_new_bytes(destination, content):
    staged = None
    try:
        with tempfile.NamedTemporaryFile(mode="wb", dir=destination.parent,
                                         prefix=".capture-", suffix=".tmp", delete=False) as output:
            staged = pathlib.Path(output.name)
            output.write(content)
            output.flush()
            os.fsync(output.fileno())
        os.link(staged, destination)
        sync_directory(destination.parent)
    finally:
        if staged is not None:
            staged.unlink(missing_ok=True)


def render(document):
    parts = ["---", json.dumps(document, ensure_ascii=False, indent=2), "---", "",
             f"# {document['title']}", "", "Status: captured; not admitted or scheduled.", "",
             "## Captured Input", ""]
    for source in document["sources"]:
        parts.extend([f"### {source['id']}", "", f"Origin: {source['origin']}", ""])
        content = base64.b64decode(source["bytes_base64"], validate=True)
        try:
            text = content.decode("utf-8")
        except UnicodeDecodeError:
            parts.extend(["Binary source retained byte-for-byte in the capture metadata.", ""])
            continue
        fence = "~" * max(3, 1 + max((len(match.group()) for match in re.finditer(r"~+", text)), default=0))
        parts.extend([fence + "text", text, fence, ""])
    parts.extend(["## Proposed Changes", ""])
    if document.get("proposal") is None:
        parts.extend(["No proposal has been created.", ""])
    else:
        proposal = document["proposal"]
        parts.extend([f"Proposal revision: {proposal['revision']}", "",
                      f"Subject SHA-256: {contract.digest(proposal)}", "",
                      "```json", json.dumps(proposal["result"], ensure_ascii=False, indent=2), "```", ""])
    return "\n".join(parts)


def validate_capture(document):
    schema = contract.object_schema({
        "schema": {"const": "cp-planning-capture-v1"}, "id": {"type": "string", "pattern": "^ADHOC-[0-9a-f]{32}$"},
        "kind": {"enum": ["ad-hoc", "discovery"]}, "title": contract.TEXT, "author": contract.TEXT,
        "created_at": contract.TEXT, "sources": {"type": "array", "items": contract.SOURCE, "minItems": 1},
        "origin": {"anyOf": [{"type": "null"}, contract.object_schema({
            "phase_id": contract.TEXT, "specification_revision": contract.POSITIVE,
            "contract_digest": contract.HASH, "contract": contract.SPECIFICATION})]},
    }, {"proposal": contract.PROPOSAL})
    contract.validate_shape(document, schema, "capture")
    contract.require(bool(IDENTITY.fullmatch(document["id"])), "invalid capture identity")
    identities = [source["id"] for source in document["sources"]]
    contract.require(len(identities) == len(set(identities)), "duplicate capture source identity")
    for source in document["sources"]:
        try:
            content = base64.b64decode(source["bytes_base64"], validate=True)
        except ValueError as error:
            raise contract.ContractError("invalid captured source encoding") from error
        contract.require(hashlib.sha256(content).hexdigest() == source["sha256"], "captured source digest mismatch")
    origin = document["origin"]
    if document["kind"] == "ad-hoc":
        contract.require(origin is None, "ad hoc capture cannot imply execution origin")
    else:
        contract.require(origin is not None, "discovery requires exact origin specification")
        contract.validate_specification(origin["contract"])
        contract.require(origin["specification_revision"] == origin["contract"]["revision"] and
                         origin["contract_digest"] == origin["contract"]["content_digest"], "origin binding mismatch")
        contract.require(origin["phase_id"] in origin["contract"]["content"]["phases"], "origin phase is missing")
        contract.require(origin["contract"]["content"]["phases"][origin["phase_id"]]["status"] == "active",
                 "origin contract must govern an active phase")
    if document.get("proposal") is not None:
        contract.require(document["proposal"]["id"] == document["id"], "proposal/capture identity mismatch")
        contract.require(document["proposal"]["sources"] == document["sources"], "proposal sources differ from original capture")
        contract.validate_content(document["proposal"]["result"])


def read_capture(filename):
    raw = filename.read_bytes().decode("utf-8")
    contract.require(raw.startswith("---\n"), "capture metadata envelope is missing")

    def unique_object(pairs):
        values = {}
        for name, value in pairs:
            contract.require(name not in values, f"duplicate capture metadata key: {name}")
            values[name] = value
        return values

    document, offset = json.JSONDecoder(object_pairs_hook=unique_object).raw_decode(raw[4:])
    contract.require(raw[4 + offset:].startswith("\n---\n"), "capture metadata boundary is invalid")
    validate_capture(document)
    contract.require(document["id"] == filename.stem, "capture identity/path mismatch")
    contract.require(raw == render(document), "capture text differs from its retained metadata; reconcile before use")
    return document


def create_capture(args):
    contract.require(args.confirmed, "capture requires explicit confirmed command authority")
    destination = capture_path(args.root, args.id)
    contract.require(bool(args.sources), "at least one explicit source is required")
    contract.require((args.kind == "discovery") == bool(args.origin_phase and args.origin_specification),
                     "discovery requires both --origin-phase and --origin-specification")
    if args.kind == "ad-hoc":
        contract.require(not args.origin_phase and not args.origin_specification, "ad hoc capture has no execution origin")
    origin = None
    if args.kind == "discovery":
        specification = contract.load_json(args.origin_specification)
        contract.validate_specification(specification)
        contract.require(args.origin_phase in specification["content"]["phases"], "origin phase is missing")
        origin = {"phase_id": args.origin_phase, "specification_revision": specification["revision"],
                  "contract_digest": specification["content_digest"], "contract": specification}
    document = {"schema": "cp-planning-capture-v1", "id": args.id, "kind": args.kind,
                "title": args.title, "author": args.author,
                "created_at": datetime.now(timezone.utc).isoformat(),
                "sources": [canonical_source(filename, index) for index, filename in enumerate(args.sources, 1)],
                "origin": origin}
    validate_capture(document)
    if destination.exists():
        previous = read_capture(destination)
        document["created_at"] = previous["created_at"]
        contract.require(document == {name: value for name, value in previous.items() if name != "proposal"},
                         "capture identity already names different inputs")
        return {"path": str(destination), "id": args.id, "created": False, "admitted": False}
    destination.parent.mkdir(parents=True, exist_ok=True)
    try:
        publish_new_bytes(destination, render(document).encode("utf-8"))
    except FileExistsError as error:
        raise contract.ContractError("capture identity was concurrently created; inspect and retry exact inputs") from error
    return {"path": str(destination), "id": args.id, "created": True, "admitted": False}


@contextmanager
def local_writer(root):
    root = root.resolve()
    local = root / "control-plane/state/planning-local"
    contract.require(local.resolve().is_relative_to(root), "local writer state escapes the repository")
    local.mkdir(parents=True, exist_ok=True)
    ignored = local / ".gitignore"
    expected = b"*\n!.gitignore\n"
    try:
        with ignored.open("xb") as output:
            output.write(expected)
    except FileExistsError:
        contract.require(not ignored.is_symlink() and ignored.read_bytes() == expected,
                         "local writer ignore policy conflicts with existing content")
    descriptor = os.open(local / "writer.lock", os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "r+") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise contract.ContractError("another local planning writer is active; retry after it finishes") from error
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def update_proposal(args):
    contract.require(args.confirmed, "proposal update requires explicit confirmed command authority")
    destination = capture_path(args.root, args.id)
    contract.require(bool(re.fullmatch(r"[0-9a-f]{64}", args.expected_digest)), "invalid expected document digest")
    base = contract.load_json(args.base)
    proposal = contract.load_json(args.proposal)
    execution = contract.load_json(args.execution)
    contract.validate_specification(base)
    contract.validate_shape(proposal, contract.PROPOSAL, "proposal")
    contract.require(proposal["base_revision"] == base["revision"] and proposal["base_digest"] == base["content_digest"],
                     "proposal base is stale")
    contract.apply_changes(base, proposal)
    contract.validate_execution(base, proposal, execution)
    with local_writer(args.root):
        original = destination.read_bytes()
        document = read_capture(destination)
        original_digest = hashlib.sha256(original).hexdigest()
        current_proposal = document.get("proposal")
        if current_proposal == proposal:
            return {"path": str(destination), "id": args.id, "updated": False,
                    "document_digest": original_digest, "admitted": False}
        contract.require(original_digest == args.expected_digest, "capture changed since the update was prepared")
        contract.require(proposal["revision"] == (current_proposal["revision"] + 1 if current_proposal else 1),
                         "changed proposal requires the next explicit proposal revision")
        document["proposal"] = proposal
        validate_capture(document)
        history = destination.parent / "assets" / args.id / "history"
        contract.require(history.resolve().is_relative_to(args.root.resolve()), "capture history escapes repository")
        history.mkdir(parents=True, exist_ok=True)
        snapshot = history / f"{original_digest}.md"
        try:
            publish_new_bytes(snapshot, original)
        except FileExistsError:
            contract.require(not snapshot.is_symlink() and snapshot.read_bytes() == original, "history snapshot mismatch")
        staged = None
        try:
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=destination.parent,
                                             prefix=".proposal-", suffix=".tmp", delete=False) as output:
                staged = pathlib.Path(output.name)
                output.write(render(document))
                output.flush()
                os.fsync(output.fileno())
            contract.require(destination.read_bytes() == original, "capture changed outside the local writer")
            os.replace(staged, destination)
            sync_directory(destination.parent)
        finally:
            if staged is not None:
                staged.unlink(missing_ok=True)
    return {"path": str(destination), "id": args.id, "updated": True, "admitted": False,
            "document_digest": hashlib.sha256(destination.read_bytes()).hexdigest(), "previous_snapshot": str(snapshot)}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("new-id", help="print a UUID-backed identity without writing")
    capture = commands.add_parser("capture")
    capture.add_argument("--root", type=pathlib.Path, default=pathlib.Path.cwd())
    capture.add_argument("--id", required=True)
    capture.add_argument("--kind", choices=["ad-hoc", "discovery"], default="ad-hoc")
    capture.add_argument("--title", required=True)
    capture.add_argument("--author", required=True)
    capture.add_argument("--source", dest="sources", action="append", type=pathlib.Path, required=True)
    capture.add_argument("--origin-phase")
    capture.add_argument("--origin-specification", type=pathlib.Path)
    capture.add_argument("--confirmed", action="store_true")
    proposed = commands.add_parser("propose", help="revise a capture's proposal, preserving its prior exact document")
    proposed.add_argument("--root", type=pathlib.Path, default=pathlib.Path.cwd())
    proposed.add_argument("--id", required=True)
    proposed.add_argument("--expected-digest", required=True)
    for name in ("base", "proposal", "execution"):
        proposed.add_argument(f"--{name}", required=True, type=pathlib.Path)
    proposed.add_argument("--confirmed", action="store_true")
    for command in ("list", "inspect"):
        reader = commands.add_parser(command)
        reader.add_argument("--root", type=pathlib.Path, default=pathlib.Path.cwd())
        if command == "inspect":
            reader.add_argument("--id", required=True)
    args = parser.parse_args()
    try:
        if args.command == "new-id":
            result = {"id": "ADHOC-" + uuid.uuid4().hex}
        elif args.command == "capture":
            result = create_capture(args)
        elif args.command == "propose":
            result = update_proposal(args)
        elif args.command == "inspect":
            result = read_capture(capture_path(args.root, args.id))
        else:
            result = []
            for filename in sorted(capture_root(args.root).glob("ADHOC-*.md")):
                document = read_capture(capture_path(args.root, filename.stem))
                contract.require(document["id"] == filename.stem, "capture identity/path mismatch")
                result.append({name: document[name] for name in ("id", "kind", "title", "author", "created_at")})
        print(json.dumps(result, indent=2, ensure_ascii=False, allow_nan=False))
        return 0
    except (contract.ContractError, OSError, ValueError) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())