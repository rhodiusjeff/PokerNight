# File-Backed Planning Contract: Integrity Core

**Status:** Executable contract under development, not the complete G-01 through G-06 design.
**Owner:** Steward under the authorized V0.8.1 upgrade. **Version:** `cp-planning-v1`.
This file specifies the first bounded part of A3. It does not duplicate the task inventory.

## Authority And Placement

Select `control-plane/operational/` for repository-owned specifications, separate from runtime
state. The first local integrity fixture represents the complete specification as JSON with
`canon`, `phases`, and `dag` sections. Canon and phase identities are stable strings; existing
identities are retained, not renumbered. Phase identity allocation, human-readable materialization,
consumer rollout, and the single-document capture adapter remain subsequent contract work.

No operational file is initialized in Poker Night by this prototype. Revision 0 is explicitly
empty, with empty sections. Populated installations are not silently relabeled as revision 0.
Execution progress is a separate input and does not advance the specification revision.

## Digest Subjects

Use the existing canonical JSON convention: UTF-8, sorted object keys, compact separators,
Unicode preserved, finite JSON numbers only. Reject duplicate object keys when reading JSON.
Revision fields require native integer JSON representation: booleans and integral floats are
rejected even where generic JSON Schema's mathematical integer type would accept the latter.
Candidate equality uses validated canonical bytes/digests, never Python's numeric equality.

- Specification content digest covers exactly `canon`, `phases`, and `dag`, not revision metadata.
- A proposal carries identity/revision/author, exact base revision and digest, explicit changes,
  the declared resulting content, captured source references, and affected execution expectations.
  Its subject digest covers that complete proposal, excluding review reports and decisions.
- Reviews name the exact proposal subject and report reviewer, independent assessment, scope,
  findings and report text. Adding a review does not invalidate its own input.
- Decisions name the proposal subject and the digest of the complete applicable review list.
  The decision includes actor/authority/date/scope, reviewed checklist, integration and DAG
  assessment, findings acknowledgment, explicit conditions, signoff and invocation provenance.
  Waivers additionally require rationale and actual alternative-review description. Waiver is
  not a switch that bypasses integrity checks or a requirement for every unresolved finding.
- Admission metadata records proposal identity/revision, subject digest, and decision digest.
  It is assembled only after those subjects exist, avoiding recursive hashes.

The prototype source envelope embeds original bytes as validated base64 plus SHA-256, identity
and origin, so binary assets and line endings are not lost. It is a retained input snapshot,
not a required second maintained proposal. Future capture adapters can materialize references
to immutable snapshots without changing the digest/retention obligations. `--schema <kind>`
prints the validator-owned schema; it is not a separately maintained schema copy.

This kernel validates supplied evidence structure and binding. It cannot authenticate a human
signature or prove reviewer independence from a boolean. The command must obtain actual actor
confirmation and independently retained review input; fixtures are never real approval evidence.
Retained source/review bytes, asset checking, and trusted forge execution remain required adapters.

## Explicit Changes And Structural Checks

Each change identifies `canon` or `phases`, a stable ID, operation `add|modify|obsolete`, prior
record digest (null for add), and new record. Reject duplicate change targets and undeclared result
changes. Obsoletion preserves the exact prior record except its applicability status; historical
references survive. The complete declared DAG must contain each active phase exactly once in its
order, valid active endpoints, unique edges and no cycle. Dependencies point prerequisite to
dependent. Family membership is not a dependency edge.

Active phases require title, complete specification text, Canon links and acceptance expectations.
Active Canon references cannot resolve to missing/obsolete records. Obsolete records remain in
the content but are excluded from the executable DAG. No-op changes do not manufacture revisions.

## Execution Race Check

Only changed phase contracts are affected by the first kernel. Canon-only changes also affect
phases whose Canon links include the changed IDs; dependency changes affect both edge endpoints
and phases whose position relative to a dependency changes. Unrelated execution progress must
not cause a false specification-base conflict.

A proposal binds the exact observed state and contract digest of affected started work. A phase
that starts/finishes between assessment and validation must trigger reconciliation. For a change
to started/completed work, the only initially supported disposition is explicit
`preserve-bound-contract`, with the full original contract retained in execution evidence.
It neither edits that execution record nor reopens completed work. More extensive continuation,
new-family-work and rework planning are subsequent command responsibilities, not automatic fixes.
Dependency impact includes the transitive dependent closure in the old and new DAGs. A retained
execution snapshot must match the content digest in its historical admission entry, not just
its own self-reported digest. Admission history is contiguous and retained in the specification
envelope; it is outside the content digest and is preserved exactly when generating a candidate.

## Result And Publication

Validation takes the immediately preceding operational specification, proposal, reviews, decision,
and current execution snapshot. It checks the base revision/digest, applies explicit changes,
validates declared content and evidence, and computes the next complete revision once.
Changed sources/proposal invalidate old evidence. Changed reviews invalidate a decision's review
binding without recursively changing the proposal. Open findings become warnings.

The CLI is read-only: it prints the validated result but never writes operational files, commits,
publishes, merges, claims work, or advances instance state. A later integration adapter must compare
the actual committed candidate to this exact result and preserve admission history. Local success
does not authorize live admission, which remains disabled pending trusted protected integration.

## Forge Decision (2026-09-28)

Operator selected: **Defer live forge tests; continue local implementation**. Keep live admission
blocked and forge verification an explicit unfinished release gate. Read-only evidence found
`rhodiusjeff/PokerNight` public, owner type `User`, no applicable `main` rules, and classic branch
protection returning `Branch not protected`. GitHub documents merge queues for organization-owned
repositories. No transfer, repository creation, protection change, or alternate weaker gate is
authorized. This deferral does not waive F1's deterministic local validation.

## Local Capture Adapter

`planning-capture.py` provides `new-id`, `capture`, `list`, `inspect`, and `propose` for the first
local trial. UUID-backed `ADHOC-*` identities use exclusive publication; exact-input retries
reuse the identity, changed inputs refuse rather than silently overwriting history. No horizon,
branch, Canon file or phase is created by capture. Discovery requires a retained, validated
origin specification and named phase; it does not claim that an arbitrary supplied snapshot is
the current integration target or authenticate an execution owner.

One maintained Markdown document lives under `control-plane/ad-hoc/`. Its JSON-compatible
frontmatter owns structured captured bytes and proposal data; the body is a checked readable
render, not a second authority. Malformed metadata, changed renders, path escapes and identity
collisions refuse. Original sources may be text or binary. No remote provider is called.

Proposal mutation requires confirmed command provenance supplied by the caller, an expected
document digest, the exact base, current execution input, and the next proposal revision.
`--confirmed` represents an already-observed Operator confirmation; it is not authentication
or a substitute for the eventual command/persona permission boundary. The runtime snapshots
prior bytes under the capture's `assets/<id>/history/` before replacing the maintained document.
Snapshot publication and replacement are flushed; retry detects matching current proposals.
The macOS/Linux writer lock is worktree-local under `control-plane/state/planning-local/`, with
an internal ignore file for local locks. Contention refuses promptly; it is not a distributed lock.

This adapter does not yet append new captures to an existing effort, manage findings/reviews,
select deferred items, move branches, transfer/absorb horizons, or publish. The shared command
and writer-grant rollout remains A4/B-D work. Do not count C1 or the whole ad hoc workflow complete
from these foundational tests, and do not automatically convert existing H000 documents.