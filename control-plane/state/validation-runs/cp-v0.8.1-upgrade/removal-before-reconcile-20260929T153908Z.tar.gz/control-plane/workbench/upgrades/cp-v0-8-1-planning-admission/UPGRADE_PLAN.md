# Upgrade Plan

**Upgrade:** `cp-v0-8-1-planning-admission`.
**Current phase:** Local implementation verified; five explicit gates remain in LOCAL_IMPLEMENTATION_REPORT.md.
**Cutover started: yes**

Cutover started with the Operator-authorized instance-schema and entry-contract edits in this
effort. This is local framework mutation, not production integration. Do not use packet `--reset`.
The earlier permission to discard disposable CP test state remains separate.

## Scope And Execution Owner

Project: Control Plane Steward owns explicitly authorized framework implementation. Facilitator
owns entry and confirmed completion; the generated coordinator cannot grant itself runtime access.
The existing [task inventory](../../2026-09-28-cp-v0.8.1-planning-capability-tasks.md) remains the
single checklist and use-case inventory. Do not create an independent tracker or duplicate tasks.
This plan supplies sequencing and recovery, not a second status graph.

## Sequence

1. Finish entry repair, validate selected packet and schema, then activate it under the confirmed
   upgrade command. Preserve old archive/history and record the actual branch baseline.
2. Resolve A's data/authority/branch/recovery contracts, consumer map, independent assessments,
   and measured test baseline before implementing dependent slices.
3. Implement shared file-backed proposal/operational validation, exercise one small ad hoc path,
   then extend the same contracts to lifecycle, deferred capture, discovery and transfer.
   Follow checklist dependencies; do not treat this sequence as authorization to skip B-F tasks.
4. Integrate admission, affected execution readers, protected merge-candidate validation and
   distribution. Verify actual forge capabilities before relying on queue/train enforcement.
5. Run bounded source-only and agent trials with visible progress. Exclude reference-derived
   product answers from trial input. Verify the external source pack before destructive local tests.
6. Present actual acceptance results and unresolved limitations; obtain separate publication and
   lifecycle-completion confirmations when needed. Do not claim release completion from entry tests.

## Verification And Progress

Monitor `control-plane/state/validation-runs/cp-v0.8.1-upgrade/progress.jsonl`. Append batch/scenario
start, completion, waits/failures, counts, elapsed time, evidence and resume points. Bound fast
checks to measured relevant suites and scope longer agent trials explicitly. No silent reruns
until green, no unseen-activity claims, and no credentials/private reasoning in the log.

Entry baseline: `upgrade-entry.test.sh` 7 checks (0.072 s), `timing-routing.test.sh` 23 checks
(20.556 s), `timing-harvest.test.sh` 2 checks (0.118 s), on macOS with Bash and PowerShell.
Static contracts are classified separately from real runtime and agent behavior. A6's broader
baseline remains outstanding.

## Recovery And Completion

Keep current edits and append a truthful progress checkpoint on interruption. Resume the exact
packet and branch; do not recreate the old upgrade, reset Git, or restart completed trials without
a changed subject/objective. Preserve exact review subjects and prior outcomes. Return to the
Steward owner for implementation; use Facilitator for confirmed lifecycle state changes.

Completion requires task evidence or explicitly agreed exclusions, coherent installed docs and
adapters, independent assessments with dispositions, distribution/trial evidence and an explicit
publication posture. The Operator confirms the exact return-to-operational action after those
conditions are presented. Archive the coordinator byte-for-byte at a unique path, preserve this
completed packet, clear active pointers and validate instance state. Neither entry success nor
this plan grants completion, merge, or product execution.