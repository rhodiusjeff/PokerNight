#!/usr/bin/env python3
"""Isolated candidates and gated publication. Public CLI is local/mock only; no live merge."""

import argparse
import copy
import fcntl
import hashlib
import importlib.util
import json
import os
import pathlib
import re
import sys
import uuid
from contextlib import contextmanager


module_spec = importlib.util.spec_from_file_location("planning_admission", pathlib.Path(__file__).with_name("planning-admission.py"))
admission = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(admission)
evidence = admission.evidence
capture = admission.capture
contract = admission.contract
planning_git = evidence.load_module("planning-git")
planning_transfer = evidence.load_module("planning-transfer")
forge = evidence.load_module("planning-forge")
ATTEMPT_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,79}\Z")
FAILURES = ("before-push", "after-push", "before-request", "after-request", "after-authorization")


def home(root):
    return evidence.confined(root, pathlib.Path(root) / "control-plane/state/planning-local/publication")


def attempt_directory(root, identity):
    contract.require(isinstance(identity, str) and bool(ATTEMPT_ID.fullmatch(identity)), "invalid immutable attempt ID")
    return evidence.confined(root, home(root) / identity)


def offer(root, bundle, target_ref, *, github_config=None, owner=None):
    root = planning_git.repository_root(pathlib.Path(root))
    contract.require(target_ref.startswith("refs/heads/") and not target_ref.endswith("/"), "explicit local integration refs/heads/... target required")
    planning_git.git(root, "check-ref-format", target_ref)
    bundle = evidence.confined(root, bundle)
    checked = admission.validate_bundle(root, bundle)
    target = planning_git.resolve_commit(root, target_ref)
    base = planning_git.blob_json(root, target, admission.SPECIFICATION_PATH)
    execution = planning_git.blob_json(root, target, admission.EXECUTION_PATH)
    manifest, document, payload, validation = admission.verify_directory(root, bundle)
    planning_transfer.guard(root, evidence.read_document(root, document["id"])[1])
    checked = contract.validate_admission(base, document["proposal"], evidence.load_bytes(payload["reviews.json"]),
                                         evidence.load_bytes(payload["decision.json"]), execution)
    contract.require(checked["already_applied_revision"] is None, "already-applied: do not publish another attempt")
    contract.require(evidence.encoded(checked["result"]) == payload["result.json"], "target changes the computed admission result")
    contract.require(planning_git.resolve_commit(root, target_ref) == target, "target moved during offer")
    value = {"schema": "cp-local-publication-offer-v1", "repository": str(root), "context_id": document["id"],
             "bundle": str(bundle.relative_to(root)), "bundle_id": checked.get("bundle_id", contract.digest(manifest)),
             "target_ref": target_ref, "target_commit": target, "proposal_digest": manifest["subjects"]["proposal_digest"],
             "decision_digest": manifest["decision_digest"], "base_digest": contract.digest(base), "transport": "local-mock"}
    if github_config is not None:
        github_config.validate()
        contract.require(target_ref == "refs/heads/" + github_config.base, "hosted base differs from local pinned target")
        value.update(schema="cp-github-publication-offer-v1", transport="github",
                     transport_config=github_config._asdict(), owner_binding=owner_binding(owner))
    return {"offer": value, "offer_digest": contract.digest(value), "live_admission": False}


def owner_binding(owner):
    contract.require(isinstance(owner, forge.OwnerIntegration) and owner.enabled is True and callable(owner.authorize),
                     forge.LIVE_BLOCKER + ": configured owner required")
    value = {name: getattr(owner, name) for name in
             ("owner", "ci_evidence", "protection_evidence", "actor_login", "actor_id")}
    contract.require(bool(value["owner"]) and all(isinstance(value[name], str) and forge.DIGEST.fullmatch(value[name])
                     for name in ("ci_evidence", "protection_evidence")), "approved CI/protection evidence required")
    return value


def immutable_json(root, filename, value):
    filename = evidence.confined(root, filename)
    content = evidence.encoded(value)
    if filename.exists():
        contract.require(filename.read_bytes() == content, "immutable publication record differs")
        return False
    capture.ensure_directory(root, filename.parent)
    capture.publish_new_bytes(filename, content)
    return True


def journal(root, directory):
    records = []
    previous = None
    journal_home = evidence.confined(root, directory / "journal")
    if not journal_home.exists():
        return records
    for index, filename in enumerate(sorted(journal_home.iterdir()), 1):
        contract.require(filename.name == f"{index:06d}.json", "publication journal sequence gap")
        record = contract.load_json(evidence.confined(root, filename))
        contract.require(record["sequence"] == index and record["previous"] == previous, "publication journal chain mismatch")
        previous = contract.digest(record)
        records.append(record)
    return records


def append_event(root, directory, state, data):
    records = journal(root, directory)
    if records and records[-1]["state"] == state and records[-1]["data"] == data:
        return
    record = {"sequence": len(records) + 1, "previous": contract.digest(records[-1]) if records else None,
              "state": state, "data": data}
    immutable_json(root, directory / "journal" / f"{len(records) + 1:06d}.json", record)


@contextmanager
def attempt_lock(root, directory):
    filename = evidence.confined(root, directory / "attempt.lock")
    descriptor = os.open(filename, os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
    with os.fdopen(descriptor, "r+") as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError as error:
            raise contract.ContractError("another writer owns this publication attempt") from error
        try:
            yield
        finally:
            fcntl.flock(lock.fileno(), fcntl.LOCK_UN)


def load_attempt(root, identity):
    root = planning_git.repository_root(pathlib.Path(root))
    directory = attempt_directory(root, identity)
    header = contract.load_json(evidence.confined(root, directory / "attempt.json"))
    contract.require(header.get("schema") in ("cp-local-publication-attempt-v1", "cp-github-publication-attempt-v1")
                     and header["id"] == identity, "invalid publication attempt")
    contract.require(header["offer"]["repository"] == str(root) and header["offer_digest"] == contract.digest(header["offer"]), "attempt offer was changed")
    contract.require(header["confirmation"].get("offer_digest") == header["offer_digest"], "attempt confirmation binding mismatch")
    evidence.attribution(header["confirmation"])
    if header["schema"] == "cp-github-publication-attempt-v1":
        contract.require(header["offer"]["transport"] == "github"
                         and header["offer"]["schema"] == "cp-github-publication-offer-v1", "invalid hosted attempt")
        configured = forge.GitHubConfig(**header["offer"]["transport_config"]).validate()
        contract.require(configured.head == "cp-admission/" + identity
                         and header["offer"]["target_ref"] == "refs/heads/" + configured.base,
                         "hosted attempt branch binding mismatch")
    else:
        contract.require(header["offer"]["transport"] == "local-mock", "invalid local transport")
    journal(root, directory)
    return root, directory, header


def create_attempt(root, offered, identity, confirmation, confirmed, *, owner=None):
    contract.require(confirmed, "publication requires explicit confirmation of the exact local/mock offer")
    evidence.attribution(confirmation)
    contract.require(confirmation.get("offer_digest") == offered.get("offer_digest"), "confirmation must bind exact offer")
    root = planning_git.repository_root(pathlib.Path(root))
    value = offered["offer"]
    contract.require(contract.digest(value) == offered["offer_digest"], "offered subject changed")
    configured = None
    if value["transport"] == "github":
        contract.require(owner_binding(owner) == value["owner_binding"], "hosted owner binding changed")
        configured = forge.GitHubConfig(**value["transport_config"]).validate()
        contract.require(configured.head == "cp-admission/" + identity, "hosted head does not belong to attempt")
    else:
        contract.require(value["transport"] == "local-mock", "unknown publication transport")
    contract.require(offer(root, value["bundle"], value["target_ref"], github_config=configured,
                           owner=owner)["offer_digest"] == offered["offer_digest"], "publication offer is stale")
    directory = attempt_directory(root, identity)
    header = {"schema": "cp-github-publication-attempt-v1" if configured else "cp-local-publication-attempt-v1", "id": identity, "offer": value,
              "offer_digest": offered["offer_digest"], "confirmation": copy.deepcopy(confirmation)}
    with capture.local_writer(root):
        header_path = evidence.confined(root, directory / "attempt.json")
        if header_path.exists():
            load_attempt(root, identity)
            contract.require(header_path.read_bytes() == evidence.encoded(header), "immutable publication record differs")
        events = journal(root, directory)
        contract.require(not any(event["state"] == "withdrawn" for event in events),
                         "withdrawn attempt identity cannot be reused")
        claims = home(root) / "claims"
        capture.ensure_directory(root, claims)
        claim_path = evidence.confined(root, claims / (value["context_id"] + ".json"))
        claim = {"attempt_id": identity, "bundle_id": value["bundle_id"]}
        if claim_path.exists():
            previous = contract.load_json(claim_path)
            if previous != claim:
                old_directory = attempt_directory(root, previous["attempt_id"])
                previous_events = journal(root, old_directory)
                contract.require(previous_events and previous_events[-1]["state"] == "withdrawn", "competing publication attempt requires withdrawal")
                capture.replace_bytes(claim_path, claim_path.read_bytes(), evidence.encoded(claim))
        else:
            immutable_json(root, claim_path, claim)
        capture.ensure_directory(root, directory)
        immutable_json(root, header_path, header)
        if not events:
            append_event(root, directory, "prepared", {"offer_digest": header["offer_digest"]})
    return inspect(root, identity)


class MockTransport:
    def __init__(self, root, directory):
        self.root = root
        self.directory = evidence.confined(root, directory / "mock")

    def push(self, identity, commit):
        value = {"attempt_id": identity, "commit": commit, "transport": "local-mock"}
        immutable_json(self.root, self.directory / "push.json", value)
        return value

    def request(self, identity, commit, target):
        value = {"id": "mock-pr/" + identity, "attempt_id": identity, "commit": commit, "target": target, "transport": "local-mock"}
        immutable_json(self.root, self.directory / "request.json", value)
        return value

    def closed(self):
        filename = evidence.confined(self.root, self.directory / "closed.json")
        return contract.load_json(filename) if filename.exists() else None

    def close(self, identity, confirmation):
        value = {"attempt_id": identity, "observation": "closed-unmerged", "confirmation": confirmation, "transport": "local-mock"}
        immutable_json(self.root, self.directory / "closed.json", value)
        return value


def expected_files(root, header):
    offered = header["offer"]
    bundle = evidence.confined(root, offered["bundle"])
    manifest, document, payload, validation = admission.verify_directory(root, bundle, offered["bundle_id"])
    contract.require(document["id"] == offered["context_id"]
                     and manifest["subjects"]["proposal_digest"] == offered["proposal_digest"]
                     and manifest["decision_digest"] == offered["decision_digest"]
                     and manifest["base_digest"] == offered["base_digest"], "attempt differs from pinned bundle subjects")
    prefix = "control-plane/operational/admissions/" + offered["bundle_id"]
    files = {prefix + "/" + name: content for name, content in payload.items()}
    files[admission.SPECIFICATION_PATH] = payload["result.json"]
    files[prefix + "/publication.json"] = evidence.encoded(header)
    paths = {"specification": admission.SPECIFICATION_PATH, "execution": admission.EXECUTION_PATH,
             **{name: prefix + "/" + name + ".json" for name in ("proposal", "reviews", "decision")}}
    return files, paths


def fresh(root, header):
    value = header["offer"]
    planning_transfer.guard(root, evidence.read_document(root, value["context_id"])[1])
    contract.require(not any(event["state"] == "withdrawn" for event in journal(root, attempt_directory(root, header["id"]))),
                     "withdrawn attempt cannot be reused")
    checked = admission.validate_bundle(root, evidence.confined(root, value["bundle"]))
    manifest = checked["manifest"]
    contract.require(value["bundle_id"] == checked["bundle_id"] and value["proposal_digest"] == manifest["subjects"]["proposal_digest"]
                     and value["decision_digest"] == manifest["decision_digest"] and value["base_digest"] == manifest["base_digest"],
                     "attempt differs from pinned bundle subjects")
    filename, current = evidence.read_document(root, value["context_id"])
    authorization = current.get("workflow", {}).get("admission", {})
    contract.require(authorization.get("status") != "authorized-for-merge" or authorization.get("attempt_id") == header["id"],
                     "another attempt owns the authorization")
    claim = contract.load_json(evidence.confined(root, home(root) / "claims" / (value["context_id"] + ".json")))
    contract.require(claim == {"attempt_id": header["id"], "bundle_id": value["bundle_id"]}, "attempt was replaced or transferred")
    contract.require(planning_git.resolve_commit(root, value["target_ref"]) == value["target_commit"], "target moved; refresh and revalidate attempt")
    return checked


def candidate(root, directory, header):
    fresh(root, header)
    commit = candidate_contents(root, directory, header)
    fresh(root, header)
    return commit


def candidate_contents(root, directory, header):
    sandbox = evidence.confined(root, directory / "repository")
    if not sandbox.exists():
        planning_git.git(directory, "clone", "--quiet", "--no-checkout", "--local", "--no-hardlinks", str(root), str(sandbox))
    contract.require((sandbox / ".git").is_dir() and not (sandbox / ".git").is_symlink(), "partial or unsafe publication clone")
    files, paths = expected_files(root, header)
    branch = "refs/heads/cp-admission/" + header["id"]
    observed = planning_git.git(sandbox, "show-ref", "--verify", "--hash", branch, check=False)
    if observed.returncode == 0:
        commit = observed.stdout.decode().strip()
        check_candidate_contents(root, directory, header, commit)
        return commit
    planning_git.git(sandbox, "read-tree", header["offer"]["target_commit"])
    for relative, content in files.items():
        filename = evidence.confined(root, sandbox / relative)
        capture.ensure_directory(root, filename.parent)
        if filename.exists():
            contract.require(filename.is_file() and filename.read_bytes() == content, "partial publication bytes changed; preserve and inspect")
        else:
            capture.publish_new_bytes(filename, content)
        blob = planning_git.git(sandbox, "hash-object", "-w", "--no-filters", "--", relative).stdout.decode().strip()
        planning_git.git(sandbox, "update-index", "--add", "--cacheinfo", f"100644,{blob},{relative}")
    tree = planning_git.git(sandbox, "write-tree").stdout.decode().strip()
    planning_git.git(sandbox, "config", "user.name", "Control Plane local mock")
    planning_git.git(sandbox, "config", "user.email", "local-mock@example.invalid")
    commit = planning_git.git(sandbox, "commit-tree", tree, "-p", header["offer"]["target_commit"],
                              "-m", "Local mock admission " + header["id"]).stdout.decode().strip()
    planning_git.git(sandbox, "update-ref", branch, commit, "0" * len(commit))
    check_candidate_contents(root, directory, header, commit)
    append_event(root, directory, "candidate-prepared", {"commit": commit})
    return commit


def check_candidate(root, directory, header, commit):
    fresh(root, header)
    result = check_candidate_contents(root, directory, header, commit)
    fresh(root, header)
    return result


def check_candidate_contents(root, directory, header, commit):
    sandbox = evidence.confined(root, directory / "repository")
    files, paths = expected_files(root, header)
    target = header["offer"]["target_commit"]
    parents = planning_git.git(sandbox, "rev-list", "--parents", "-n", "1", commit).stdout.decode().split()
    contract.require(parents == [commit, target], "candidate must have exactly the explicit integration target as parent")
    merged = planning_git.git(sandbox, "merge-tree", "--write-tree", "--name-only", "-z", target, commit, check=False)
    contract.require(merged.returncode == 0, "candidate has a real Git merge conflict")
    tree = merged.stdout.split(b"\0")[0].decode().strip()
    raw = planning_git.git(sandbox, "diff-tree", "--no-commit-id", "--name-status", "--no-renames", "-r", "-z", target, tree).stdout
    inventory = [token.decode("utf-8", "surrogateescape") for token in raw.split(b"\0") if token]
    contract.require(set(inventory[1::2]) == set(files), "unexpected or missing whole-candidate inventory")
    entries = planning_git.git(sandbox, "ls-tree", "-r", "-z", tree, "--",
                               *(":(literal)" + relative for relative in files)).stdout
    blobs = {}
    for entry in entries.split(b"\0"):
        if entry:
            metadata, relative = entry.split(b"\t", 1)
            blobs[relative.decode("utf-8", "surrogateescape")] = metadata.split()
    contract.require(set(blobs) == set(files), "unexpected or missing candidate blobs")
    contract.require(len(tree) in (40, 64), "unsupported Git object format")
    for relative, content in files.items():
        mode, kind, blob = blobs[relative]
        contract.require(mode == b"100644" and kind == b"blob", "candidate artifact mode is not regular")
        expected_blob = hashlib.new("sha1" if len(tree) == 40 else "sha256",
                                    b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest()
        contract.require(blob.decode() == expected_blob, "candidate artifact bytes changed")
    core_paths = {paths[name] for name in ("specification", "proposal", "reviews", "decision")}
    core_inventory = [token for offset in range(0, len(inventory), 2) if inventory[offset + 1] in core_paths
                      for token in inventory[offset:offset + 2]]
    result = planning_git.validate_candidate(sandbox, target, commit, tree, paths, core_inventory)
    contract.require(result["status"] == "candidate-valid", "local candidate refused: " + result.get("reason", result["status"]))
    return {**result, "whole_candidate_inventory": inventory, "commit": commit, "live_admission": False}


def inject(selected, point):
    if selected == point:
        raise contract.ContractError("injected local/mock publication failure: " + point)


def integrated_observation(root, header):
    value = header["offer"]
    target = planning_git.resolve_commit(root, value["target_ref"])
    base = planning_git.blob_json(root, target, admission.SPECIFICATION_PATH)
    contract.validate_specification(base)
    entries = [entry for entry in base["admissions"] if entry["proposal_id"] == value["context_id"]]
    if not entries:
        return None
    manifest, document, payload, original = admission.verify_directory(root, evidence.confined(root, value["bundle"]), value["bundle_id"])
    contract.require(entries == [original["result"]["admissions"][-1]], "integrated admission provenance differs from this attempt")
    files, paths = expected_files(root, header)
    for relative, content in files.items():
        if relative == admission.SPECIFICATION_PATH:
            continue
        entry = planning_git.git(root, "ls-tree", "-z", target, "--", relative).stdout
        contract.require(entry.startswith(b"100644 blob "), "integrated admission evidence is missing or not regular")
        contract.require(planning_git.git(root, "show", f"{target}:{relative}").stdout == content, "integrated admission evidence bytes differ")
    contract.require(planning_git.resolve_commit(root, value["target_ref"]) == target, "target moved during admission observation")
    return {"attempt_id": header["id"], "state": "already-applied", "revision": entries[0]["revision"],
            "target_commit": target, "target_freshness": "locally-observed-ref; not hosted attestation",
            "transport": "local-mock", "live_admission": False}


def resume(root, identity, confirmed, fail_at=None):
    contract.require(confirmed, "resuming local/mock publication requires explicit confirmed command authority")
    contract.require(fail_at is None or fail_at in FAILURES, "unknown failure injection")
    root, directory, header = load_attempt(root, identity)
    with attempt_lock(root, directory):
        events = journal(root, directory)
        planning_transfer.guard(root, evidence.read_document(root, header["offer"]["context_id"])[1])
        contract.require(header["offer"]["transport"] == "local-mock", forge.LIVE_BLOCKER)
        contract.require(not any(event["state"] == "withdrawn" for event in events), "withdrawn attempt cannot resume")
        integrated = integrated_observation(root, header)
        if integrated is not None:
            return integrated
        transport = MockTransport(root, directory)
        if transport.closed():
            return {"attempt_id": identity, "state": "closed-unmerged", "live_admission": False,
                    "next_action": "Explicit withdrawal and refreshed offer required; no lifecycle change inferred."}
        try:
            commit = candidate(root, directory, header)
            inject(fail_at, "before-push")
            pushed = transport.push(identity, commit)
            inject(fail_at, "after-push")
            append_event(root, directory, "push-confirmed", pushed)
            fresh(root, header)
            inject(fail_at, "before-request")
            request = transport.request(identity, commit, header["offer"]["target_ref"])
            inject(fail_at, "after-request")
            append_event(root, directory, "request-open", request)
            fresh(root, header)
            filename, document = evidence.read_document(root, header["offer"]["context_id"])
            expected = evidence.retain(filename.read_bytes())["sha256"]

            def authorize(current):
                fresh(root, header)
                return admission.record_authorization(current, header["offer"]["bundle_id"], identity,
                    header["offer"]["target_ref"], header["offer"]["target_commit"], commit, request["id"], header["confirmation"])

            if document.get("workflow", {}).get("admission", {}).get("status") == "authorized-for-merge":
                authorize(copy.deepcopy(document))
            else:
                evidence.mutate(root, header["offer"]["context_id"], expected, authorize, True)
            inject(fail_at, "after-authorization")
            append_event(root, directory, "authorized-for-merge", {"commit": commit, "request_id": request["id"], "transport": "local-mock"})
            return {"attempt_id": identity, "state": "authorized-for-merge", "request_id": request["id"],
                    "commit": commit, "transport": "local-mock", "live_admission": False}
        except (ValueError, OSError) as error:
            append_event(root, directory, "publication-failed", {"reason": str(error)})
            raise


def inspect(root, identity):
    root, directory, header = load_attempt(root, identity)
    events = journal(root, directory)
    hosted = header["offer"]["transport"] == "github"
    closed = None if hosted else MockTransport(root, directory).closed()
    state = events[-1]["state"] if events else "prepared"
    return {"attempt_id": identity, "state": state if state == "withdrawn" else "closed-unmerged" if closed else state,
            "offer": header["offer"], "events": events, "transport": "github" if hosted else "local-mock", "live_admission": False}


def close_request(root, identity, confirmation, confirmed):
    contract.require(confirmed, "local/mock close observation requires explicit confirmation")
    evidence.attribution(confirmation)
    root, directory, header = load_attempt(root, identity)
    contract.require(header["offer"]["transport"] == "local-mock", forge.LIVE_BLOCKER)
    with attempt_lock(root, directory):
        integrated = integrated_observation(root, header)
        if integrated is not None:
            return integrated
        if any(event["state"] == "withdrawn" for event in journal(root, directory)):
            return inspect(root, identity)
        closed = MockTransport(root, directory).close(identity, confirmation)
        append_event(root, directory, "closed-unmerged", closed)
    return inspect(root, identity)


def withdraw(root, identity, confirmation, confirmed):
    contract.require(confirmed, "withdrawal requires explicit confirmation")
    evidence.attribution(confirmation)
    root, directory, header = load_attempt(root, identity)
    contract.require(header["offer"]["transport"] == "local-mock", forge.LIVE_BLOCKER)
    with attempt_lock(root, directory):
        target = planning_git.resolve_commit(root, header["offer"]["target_ref"])
        base = planning_git.blob_json(root, target, admission.SPECIFICATION_PATH)
        contract.validate_specification(base)
        contract.require(not any(item["proposal_id"] == header["offer"]["context_id"] for item in base["admissions"]),
                         "already integrated locally; withdrawal cannot rewrite that fact")
        transport = MockTransport(root, directory)
        if not transport.closed():
            transport.close(identity, confirmation)
        filename, document = evidence.read_document(root, header["offer"]["context_id"])
        active = document.get("workflow", {}).get("admission", {})
        if active.get("attempt_id") == identity:
            admission.withdraw(root, document["id"], identity, evidence.retain(filename.read_bytes())["sha256"],
                               {**confirmation, "attempt_id": identity, "request_closed": True}, True)
        else:
            contract.require(active.get("status") != "authorized-for-merge", "cannot withdraw another attempt's authorization")
        append_event(root, directory, "withdrawn", {"confirmation": confirmation, "target_commit": target})
    return inspect(root, identity)


def withdrawal_authorization(root, directory, header):
    value = header["offer"]
    claim = contract.load_json(evidence.confined(root, home(root) / "claims" / (value["context_id"] + ".json")))
    contract.require(claim == {"attempt_id": header["id"], "bundle_id": value["bundle_id"]}, "attempt was replaced or transferred")
    contract.require(planning_git.resolve_commit(root, value["target_ref"]) == value["target_commit"], "target moved during withdrawal recovery")
    current = evidence.read_document(root, value["context_id"])[1]
    contract.require(current["id"] == value["context_id"], "capture identity differs from attempt")
    admission.eligible(current)
    planning_transfer.guard(root, current)
    active = current.get("workflow", {}).get("admission", {})
    contract.require(active.get("status") != "authorized-for-merge" or active.get("attempt_id") == header["id"],
                     "another attempt owns authorization")
    contract.require(not any(event["state"] == "withdrawn" for event in journal(root, directory)),
                     "withdrawn attempt cannot be reused")
    return active


def check_withdrawal_intent(root, directory, header, intent):
    withdrawal_intent_current(root, directory, header, intent)
    check_candidate_contents(root, directory, header, intent["commit"])


def withdrawal_intent_current(root, directory, header, intent):
    contract.require(intent["confirmation"].get("offer_digest") == header["offer_digest"]
                     and intent["confirmation"].get("attempt_id") == header["id"], "withdrawal intent binding changed")
    active = withdrawal_authorization(root, directory, header)
    expected = copy.deepcopy(intent["authorization"])
    if expected.get("attempt_id") == header["id"]:
        expected["status"] = "withdrawn"
        expected["withdrawal"] = intent["withdrawal"]
        expected["history"].append({"action": "withdrawn", "confirmation": intent["withdrawal"]})
    contract.require(active == intent["authorization"] or active == expected,
                     "capture authorization/history differs from retained withdrawal intent")


def require_unmodified_git_objects(root):
    replacements = planning_git.git(root, "for-each-ref", "--format=%(refname)", "refs/replace/").stdout
    grafts = pathlib.Path(planning_git.git(root, "rev-parse", "--git-path", "info/grafts").stdout.decode().strip())
    if not grafts.is_absolute():
        grafts = root / grafts
    contract.require(not replacements and not grafts.exists() and not grafts.is_symlink(),
                     "Git replacement refs or grafts are not allowed for bound publication")


def hosted_transport(root, directory, header, owner, *, http=None, git_runner=None, withdrawal_intent=None):
    contract.require(header["offer"]["transport"] == "github", "hosted attempt required")
    contract.require(owner_binding(owner) == header["offer"]["owner_binding"], "hosted owner binding changed")
    header = copy.deepcopy(header)
    withdrawal_intent = copy.deepcopy(withdrawal_intent)
    sandbox = evidence.confined(root, directory / "repository")
    require_unmodified_git_objects(root)
    if sandbox.exists():
        require_unmodified_git_objects(sandbox)
    files, paths = expected_files(root, header)
    expected_digest = contract.digest({relative: evidence.retain(content)["sha256"] for relative, content in files.items()})
    commit = candidate(root, directory, header) if withdrawal_intent is None else withdrawal_intent["commit"]
    configured = forge.GitHubConfig(**header["offer"]["transport_config"])
    binding = forge.CandidateBinding(header["id"], header["offer_digest"], header["offer"]["bundle_id"],
                                    contract.digest(header["confirmation"]), header["offer"]["target_commit"],
                                    commit, evidence.confined(root, directory / "repository"))
    checked_subject = (commit, expected_digest) if withdrawal_intent is None else None

    def validate():
        nonlocal checked_subject
        require_unmodified_git_objects(root)
        require_unmodified_git_objects(sandbox)
        if withdrawal_intent is None:
            fresh(root, header)
        else:
            withdrawal_intent_current(root, directory, header, withdrawal_intent)
        contract.require(bool(forge.SHA.fullmatch(commit)) and planning_git.resolve_commit(sandbox, commit) == commit,
                         "bound candidate commit identity changed")
        files, paths = expected_files(root, header)
        subject = (commit, contract.digest({relative: evidence.retain(content)["sha256"]
                                           for relative, content in files.items()}))
        contract.require(checked_subject is None or checked_subject == subject, "bound candidate bytes changed")
        if checked_subject is None:
            check_candidate_contents(root, directory, header, commit)
            checked_subject = subject
        if withdrawal_intent is None:
            fresh(root, header)
        else:
            withdrawal_intent_current(root, directory, header, withdrawal_intent)
        return True

    def observe(state, data):
        append_event(root, directory, state, data)

    return forge.bind_candidate(configured, binding, owner, validate, observe, http=http, git_runner=git_runner,
                               creation_pending=any(event["state"] == "request-create-intent"
                                                    for event in journal(root, directory)))


def hosted_authorization(document, header, commit, request):
    previous = copy.deepcopy(document.get("workflow", {}).get("admission", {}))
    clean = copy.deepcopy(document)
    clean.setdefault("workflow", {}).pop("admission", None)
    admission.record_authorization(clean, header["offer"]["bundle_id"], header["id"],
        header["offer"]["target_ref"], header["offer"]["target_commit"], commit, request["id"], header["confirmation"])
    authorization = clean["workflow"]["admission"]
    authorization["transport"] = "github"
    authorization["history"] = [*previous.get("history", []),
        {**authorization["history"][-1], "transport": "github"}]
    if previous.get("status") == "authorized-for-merge":
        contract.require({key: value for key, value in previous.items() if key != "history"} ==
                         {key: value for key, value in authorization.items() if key != "history"},
                         "competing hosted authorization; withdraw it first")
        return document
    document.setdefault("workflow", {})["admission"] = authorization
    return document


def resume_hosted(root, identity, confirmed, owner, *, http=None, git_runner=None):
    contract.require(confirmed, "hosted retry requires exact confirmed authority; confirmation is not authentication")
    root, directory, header = load_attempt(root, identity)
    with attempt_lock(root, directory):
        contract.require(not evidence.confined(root, directory / "withdrawal-intent.json").exists(),
                         "withdrawal intent exists; reconcile withdrawal before publication")
        current = evidence.read_document(root, header["offer"]["context_id"])[1]
        authorization = current.get("workflow", {}).get("admission", {})
        contract.require(not (authorization.get("attempt_id") == identity and authorization.get("status") == "withdrawn"),
                         "withdrawn attempt cannot resume")
        transport = hosted_transport(root, directory, header, owner, http=http, git_runner=git_runner)
        append_event(root, directory, "hosted-confirmation", {"confirmation": header["confirmation"],
                     "owner_binding": header["offer"]["owner_binding"], "offer_digest": header["offer_digest"]})
        try:
            with transport.session():
                transport.push()
                request = transport.request()
                if request["state"] != "request-open":
                    return request
                fresh(root, header)
                filename, document = evidence.read_document(root, header["offer"]["context_id"])

                def authorize(current):
                    fresh(root, header)
                    transport.refs()
                    observed, value = transport.find()
                    contract.require(observed == request, "request changed before capture authorization")
                    return hosted_authorization(current, header, transport.binding.commit, request)

                if document.get("workflow", {}).get("admission", {}).get("status") == "authorized-for-merge":
                    authorize(copy.deepcopy(document))
                else:
                    evidence.mutate(root, header["offer"]["context_id"], evidence.retain(filename.read_bytes())["sha256"], authorize, True)
                append_event(root, directory, "authorized-for-merge", request)
                return {**request, "state": "authorized-for-merge"}
        except (ValueError, OSError):
            append_event(root, directory, "hosted-publication-failed", {"reason": "hosted operation refused; reconcile exact attempt"})
            raise


def withdraw_hosted(root, identity, confirmation, confirmed, owner, *, http=None, git_runner=None):
    contract.require(confirmed, "hosted withdrawal requires explicit confirmation")
    evidence.attribution(confirmation)
    root, directory, header = load_attempt(root, identity)
    contract.require(confirmation.get("offer_digest") == header["offer_digest"]
                     and confirmation.get("attempt_id") == identity, "withdrawal confirmation must bind exact attempt")
    with attempt_lock(root, directory):
        contract.require(header["offer"]["transport"] == "github"
                         and owner_binding(owner) == header["offer"]["owner_binding"], "hosted owner binding changed")
        previous = [event for event in journal(root, directory) if event["state"] == "withdrawn"]
        if previous:
            contract.require(previous[-1]["data"]["confirmation"] == confirmation, "withdrawal retry changed confirmation")
            return inspect(root, identity)
        contract.require(callable(owner.withdrawal_guard), "trusted non-integration/withdrawal guard unavailable")
        intent_path = evidence.confined(root, directory / "withdrawal-intent.json")
        intent = contract.load_json(intent_path) if intent_path.exists() else None
        if intent is not None:
            contract.require(intent["confirmation"] == confirmation, "withdrawal retry changed confirmation")
        active = evidence.read_document(root, header["offer"]["context_id"])[1].get("workflow", {}).get("admission", {})
        contract.require(active.get("status") != "authorized-for-merge" or active.get("attempt_id") == identity,
                         "another attempt owns authorization")
        contract.require(active.get("status") != "withdrawn" or active.get("attempt_id") != identity or intent is not None,
                         "withdrawn capture lacks retained withdrawal intent")
        request_ids = {event["data"]["id"] for event in journal(root, directory)
                       if event["state"] in ("request-observed", "request-closed-observed", "authorized-for-merge")}
        if active.get("attempt_id") == identity:
            request_ids.add(active["request_id"])
        if intent is not None and "id" in intent["closure"]:
            request_ids.add(intent["closure"]["id"])
        contract.require(len(request_ids) <= 1, "recorded request identity changed")
        expected_number = None
        if request_ids:
            request_id = request_ids.pop()
            prefix = "https://github.com/" + header["offer"]["transport_config"]["repository"] + "/pull/"
            contract.require(isinstance(request_id, str) and request_id.startswith(prefix)
                             and re.fullmatch(r"[1-9][0-9]*", request_id[len(prefix):]), "invalid recorded request identity")
            expected_number = int(request_id[len(prefix):])
        cancel = expected_number is None and (intent is None or intent["closure"]["state"] == "cancelled-unpublished")
        if cancel:
            contract.require(not any(event["state"] in ("push-intent", "request-create-intent")
                                     for event in journal(root, directory)),
                             "mutating publication intent exists; unpublished cancellation is uncertain")
        transport_intent = intent
        if cancel and intent is None:
            active = withdrawal_authorization(root, directory, header)
            transport_intent = {"confirmation": confirmation, "authorization": active, "withdrawal": {},
                                "commit": candidate_contents(root, directory, header)}
        transport = hosted_transport(root, directory, header, owner, http=http, git_runner=git_runner,
                                     withdrawal_intent=transport_intent)
        with transport.session(), owner.withdrawal_guard(transport.config, transport.binding, copy.deepcopy(confirmation)) as proof:
            contract.require(isinstance(proof, dict) and proof.get("not_integrated") is True
                             and proof.get("writers_excluded") is True and proof.get("offer_digest") == header["offer_digest"]
                             and proof.get("target_commit") == transport.binding.target_commit
                             and isinstance(proof.get("evidence_digest"), str)
                             and bool(forge.DIGEST.fullmatch(proof["evidence_digest"])), "trusted withdrawal guard refused")
            closed = transport.absent() if cancel else transport.close(expected_number)
            proof = dict(not_integrated=True, writers_excluded=True, offer_digest=header["offer_digest"], target_commit=transport.binding.target_commit, evidence_digest=proof["evidence_digest"])
            contract.require(integrated_observation(root, header) is None, "already integrated locally")
            if cancel:
                observed = transport.absent()
            else:
                transport.refs()
                observed, value = transport.find(closed["number"])
            contract.require(observed == closed, "request changed during withdrawal")
            filename, document = evidence.read_document(root, header["offer"]["context_id"])
            active = document.get("workflow", {}).get("admission", {})
            if intent is None:
                withdrawal = {**confirmation, "request_closed": not cancel, "transport": "github", "closure": closed, "guard": proof}
                intent = {"confirmation": confirmation, "commit": transport.binding.commit, "closure": closed,
                          "authorization": active, "withdrawal": withdrawal}
                immutable_json(root, intent_path, intent)
            contract.require(intent["closure"] == closed, "closure differs from retained withdrawal intent")
            check_withdrawal_intent(root, directory, header, intent)
            if active.get("attempt_id") == identity:
                if active.get("status") != "withdrawn":
                    admission.withdraw(root, document["id"], identity, evidence.retain(filename.read_bytes())["sha256"],
                                       intent["withdrawal"], True)
            else:
                contract.require(active.get("status") != "authorized-for-merge", "another attempt owns authorization")
            append_event(root, directory, "withdrawn", {"confirmation": confirmation, "closure": closed, "guard": proof})
    return inspect(root, identity)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=pathlib.Path, default=pathlib.Path.cwd())
    parser.add_argument("--transport", choices=("local-mock", "github"), default="local-mock")
    commands = parser.add_subparsers(dest="command", required=True)
    commands.add_parser("new-id", help="print a UUID attempt ID without writes")
    offered = commands.add_parser("offer", help="read-only exact local-target offer; no remote access")
    offered.add_argument("--bundle", required=True, type=pathlib.Path)
    offered.add_argument("--target", required=True)
    create = commands.add_parser("create", help="persist immutable confirmed local/mock attempt")
    create.add_argument("--offer", required=True, type=pathlib.Path)
    for name in ("create", "resume", "inspect", "close-mock", "withdraw"):
        command = create if name == "create" else commands.add_parser(name)
        command.add_argument("--attempt", required=True)
        if name != "inspect":
            command.add_argument("--confirmed", action="store_true")
        if name in ("create", "close-mock", "withdraw"):
            command.add_argument("--confirmation", required=True, type=pathlib.Path)
        if name == "resume":
            command.add_argument("--fail-at", choices=FAILURES)
    for command in commands.choices.values():
        command.add_argument("--transport", choices=("local-mock", "github"), default=argparse.SUPPRESS)
    args = parser.parse_args()
    try:
        contract.require(args.transport == "local-mock", forge.LIVE_BLOCKER)
        if args.command == "new-id":
            result = {"attempt_id": uuid.uuid4().hex, "live_admission": False}
        elif args.command == "offer":
            result = offer(args.root, args.bundle, args.target)
        elif args.command == "inspect":
            result = inspect(args.root, args.attempt)
        elif args.command == "resume":
            result = resume(args.root, args.attempt, args.confirmed, args.fail_at)
        else:
            confirmation = contract.load_json(evidence.confined(args.root, args.confirmation))
            if args.command == "create":
                offered = contract.load_json(evidence.confined(args.root, args.offer))
                result = create_attempt(args.root, offered, args.attempt, confirmation, args.confirmed)
            else:
                operation = close_request if args.command == "close-mock" else withdraw
                result = operation(args.root, args.attempt, confirmation, args.confirmed)
        print(json.dumps(result, indent=2, ensure_ascii=False))
        return 0
    except (ValueError, OSError, KeyError, TypeError) as error:
        print(str(error), file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())