#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
if [[ -z "${PLANNING_PUBLICATION_TEST_FILTER:-}" ]]; then
	PLANNING_TEST_PUBLICATION=1 bash "$SCRIPT_DIR/planning-admission.test.sh"
fi
python3 - "$SCRIPT_DIR" <<'PY'
import contextlib
import copy
import importlib.util
import io
import json
import os
import pathlib
import subprocess
import sys
import tempfile
from types import SimpleNamespace
import unittest
from unittest import mock

script_directory = pathlib.Path(sys.argv.pop())
spec = importlib.util.spec_from_file_location("publication", script_directory / "planning-publication.py")
publication = importlib.util.module_from_spec(spec)
spec.loader.exec_module(publication)


class PublicationReviewRegressions(unittest.TestCase):
	def setUp(self):
		temporary = tempfile.TemporaryDirectory()
		self.addCleanup(temporary.cleanup)
		self.root = pathlib.Path(temporary.name).resolve()
		self.evidence = publication.evidence
		self.capture = publication.capture
		self.contract = publication.contract
		self.git = publication.planning_git.git
		self.authority = {"actor": "Fixture Operator", "authority": "fixture only", "date": "2026-09-29",
			"rationale": "Bounded review regression", "evidence": "fixture://review-fix"}
		self.base = self.contract.empty_specification()
		self.base_path = self.root / publication.admission.SPECIFICATION_PATH
		self.execution_path = self.root / publication.admission.EXECUTION_PATH
		for filename, value in ((self.base_path, self.base), (self.execution_path, {"phases": {}, "contracts": {}})):
			filename.parent.mkdir(parents=True, exist_ok=True)
			filename.write_bytes(self.evidence.encoded(value))
		self.git(self.root, "init", "--quiet", "-b", "integration")
		self.git(self.root, "config", "user.name", "Local Fixture")
		self.git(self.root, "config", "user.email", "fixture@example.invalid")
		self.git(self.root, "add", "--", publication.admission.SPECIFICATION_PATH, publication.admission.EXECUTION_PATH)
		self.git(self.root, "commit", "--quiet", "-m", "Local fixture baseline")
		self.target = publication.planning_git.resolve_commit(self.root, "refs/heads/integration")
		self.git(self.root, "switch", "--quiet", "-c", "planning")

	def context_offer(self, suffix):
		identity = "ADHOC-" + suffix * 32
		source = self.root / (suffix + ".txt")
		source.write_bytes(b"Exact local fixture source")
		self.capture.create_capture(SimpleNamespace(root=self.root, id=identity, confirmed=True, sources=[source],
			kind="ad-hoc", origin_phase=None, origin_specification=None, title="Fixture", author="Fixture Author"))
		filename = self.capture.resolve_document(self.root, identity)
		document = self.capture.read_capture(filename)
		canon = {"kind": "requirement", "text": "Fixture requirement", "status": "active", "sources": ["source-1"]}
		content = copy.deepcopy(self.base["content"])
		content["canon"]["REQ-1"] = canon
		document["proposal"] = {"schema": "cp-plan-proposal-v1", "id": identity, "revision": 1,
			"author": "Fixture Author", "base_revision": 0, "base_digest": self.base["content_digest"],
			"sources": document["sources"], "changes": [{"collection": "canon", "id": "REQ-1", "operation": "add",
			"before_digest": None, "value": canon}], "result": content, "execution_expectations": {}}
		review_id = self.evidence.record_review(document, "review-1", self.evidence.subject(document), b"Independent fixture report",
			[], {**self.authority, "actor": "Independent Fixture Reviewer", "scope": "Complete fixture", "independent": True}, True)
		fields = {"kind": "approval", "actor": self.authority["actor"], "authority": self.authority["authority"],
			"date": self.authority["date"], "scope": "Complete fixture", "checklist": dict.fromkeys(self.contract.CHECK_NAMES, True),
			"integration_assessment": "Fixture only", "dag_assessment": "Empty DAG", "findings_acknowledged": [],
			"conditions": [], "signoff": "Synthetic fixture signoff", "invocation_source": "operator-confirmation"}
		digest = self.evidence.draft_decision(document, "decision-1", [review_id], fields)
		decision = document["workflow"]["decision"]["drafts"][0]["decision"]
		self.evidence.finalize_decision(document, "decision-1", digest,
			{**self.authority, "decision_digest": self.contract.digest(decision)}, True)
		filename.write_text(self.capture.render(document))
		bundle = publication.admission.prepare(self.root, identity, "decision-1", self.base_path, self.execution_path,
			self.evidence.retain(filename.read_bytes())["sha256"], True)["bundle"]
		return publication.offer(self.root, bundle, "refs/heads/integration")

	def create(self, offered, identity):
		result = publication.create_attempt(self.root, offered, identity,
			{**self.authority, "offer_digest": offered["offer_digest"]}, True)
		self.assertTrue(result["events"])
		self.assertEqual(result["events"][0]["state"], "prepared")
		return result

	def snapshot(self):
		return {str(filename.relative_to(self.root)): filename.read_bytes()
			for filename in (self.root / "control-plane").rglob("*") if filename.is_file()}

	def test_cross_context_attempt_reuse_does_not_create_claim(self):
		owner = self.context_offer("a")
		other = self.context_offer("b")
		self.create(owner, "owned-attempt")
		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "immutable publication record differs"):
			self.create(other, "owned-attempt")
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(self.create(other, "other-attempt")["state"], "prepared")

	def test_cross_context_reuse_preserves_withdrawn_claim(self):
		owner = self.context_offer("a")
		other = self.context_offer("b")
		self.create(owner, "owned-attempt")
		self.create(other, "other-attempt")
		publication.withdraw(self.root, "other-attempt", self.authority, True)
		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "immutable publication record differs"):
			self.create(other, "owned-attempt")
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(self.create(other, "fresh-attempt")["state"], "prepared")

	def test_withdrawn_attempt_reuse_does_not_replace_newer_claim(self):
		offered = self.context_offer("a")
		for identity in ("old-attempt", "newer-attempt"):
			self.create(offered, identity)
			publication.withdraw(self.root, identity, self.authority, True)
		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "withdrawn"):
			self.create(offered, "old-attempt")
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(self.create(offered, "fresh-attempt")["state"], "prepared")

	def test_close_after_real_local_integration_returns_existing_revision(self):
		offered = self.context_offer("a")
		self.create(offered, "integrated-attempt")
		result = publication.resume(self.root, "integrated-attempt", True)
		directory = publication.attempt_directory(self.root, "integrated-attempt")
		self.git(self.root, "fetch", "--quiet", "--no-tags", "--no-write-fetch-head", str(directory / "repository"),
			"refs/heads/cp-admission/integrated-attempt")
		self.git(self.root, "update-ref", "refs/heads/integration", result["commit"], self.target)
		before = self.snapshot()
		for retry in range(2):
			observed = publication.close_request(self.root, "integrated-attempt", self.authority, True)
			self.assertEqual(observed["state"], "already-applied")
			self.assertEqual(observed["revision"], 1)
			self.assertEqual(observed["target_commit"], result["commit"])
			self.assertFalse(observed["live_admission"])
			self.assertEqual(self.snapshot(), before)
		self.assertIsNone(publication.MockTransport(self.root, directory).closed())
		self.assertNotIn("closed-unmerged", [event["state"] for event in publication.journal(self.root, directory)])

	def test_dedicated_withdrawal_reenables_evidence_mutation(self):
		offered = self.context_offer("a")
		self.create(offered, "authorized-attempt")
		publication.resume(self.root, "authorized-attempt", True)
		identity = offered["offer"]["context_id"]
		filename = self.capture.resolve_document(self.root, identity)

		def update(document):
			self.evidence.record_round(document, "SCRUB", "after-withdrawal", "Fixture report", [],
				"Fixture Reviewer", "2026-09-29")
			return document

		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "withdrawal"):
			self.evidence.mutate(self.root, identity, self.evidence.retain(filename.read_bytes())["sha256"], update, True)
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(publication.withdraw(self.root, "authorized-attempt", self.authority, True)["state"], "withdrawn")
		result = self.evidence.mutate(self.root, identity, self.evidence.retain(filename.read_bytes())["sha256"], update, True)
		self.assertTrue(result["updated"])
		self.assertEqual(self.capture.read_capture(filename)["workflow"]["admission"]["status"], "withdrawn")


class TransferPublicationGuards(unittest.TestCase):
	def setUp(self):
		temporary = tempfile.TemporaryDirectory()
		self.addCleanup(temporary.cleanup)
		self.root = pathlib.Path(temporary.name).resolve()
		self.document = {"id": "H008", "context": {"state": "planning", "transfers": [{"publication": "local-only/incomplete"}]}}

	def test_offer_checks_current_survivor_before_returning_offer(self):
		with mock.patch.object(publication.planning_git, "repository_root", return_value=self.root), \
			 mock.patch.object(publication.planning_git, "git"), \
			 mock.patch.object(publication.planning_git, "resolve_commit", return_value="a" * 40), \
			 mock.patch.object(publication.planning_git, "blob_json", return_value={}), \
			 mock.patch.object(publication.admission, "validate_bundle", return_value={}), \
			 mock.patch.object(publication.admission, "verify_directory", return_value=({}, self.document, {}, {})), \
			 mock.patch.object(publication.evidence, "read_document", return_value=(self.root / "capture.md", self.document)):
			with self.assertRaisesRegex(ValueError, "transfer publication incomplete"):
				publication.offer(self.root, self.root / "bundle", "refs/heads/integration")

	def test_fresh_refuses_retired_source_before_candidate_work(self):
		self.document["context"] = {"state": "absorbed"}
		with mock.patch.object(publication.evidence, "read_document", return_value=(self.root / "capture.md", self.document)):
			with self.assertRaisesRegex(ValueError, "retired transfer source"):
				publication.fresh(self.root, {"offer": {"context_id": "H008"}})

	def test_resume_refuses_survivor_before_integration_observation(self):
		header = {"offer": {"context_id": "H008"}}
		with mock.patch.object(publication, "load_attempt", return_value=(self.root, self.root, header)), \
			 mock.patch.object(publication, "attempt_lock", return_value=contextlib.nullcontext()), \
			 mock.patch.object(publication, "journal", return_value=[]), \
			 mock.patch.object(publication.evidence, "read_document", return_value=(self.root / "capture.md", self.document)), \
			 mock.patch.object(publication, "integrated_observation") as integrated:
			with self.assertRaisesRegex(ValueError, "transfer publication incomplete"):
				publication.resume(self.root, "old-attempt", True)
			integrated.assert_not_called()


class HostedControllerTests(unittest.TestCase):
	context_offer = PublicationReviewRegressions.context_offer
	snapshot = PublicationReviewRegressions.snapshot

	def setUp(self):
		PublicationReviewRegressions.setUp(self)
		self.forge = publication.forge
		self.identity = "hosted-attempt"
		self.config = self.forge.GitHubConfig("github.com", "fixture/repo", 12, "integration", "cp-admission/" + self.identity)
		self.owner = self.forge.OwnerIntegration(True, "fixture-owner", "1" * 64, "2" * 64,
			"fixture-actor", 23, lambda config, binding, action: True, self.guard, self.publication_guard)
		local = self.context_offer("a")
		self.offered = publication.offer(self.root, local["offer"]["bundle"], local["offer"]["target_ref"],
			github_config=self.config, owner=self.owner)
		self.confirmation = {**self.authority, "offer_digest": self.offered["offer_digest"]}
		publication.create_attempt(self.root, self.offered, self.identity, self.confirmation, True, owner=self.owner)
		self.directory = publication.attempt_directory(self.root, self.identity)
		self.bare = self.root / "fixture-remote.git"
		self.git(self.root, "clone", "--bare", "--quiet", str(self.root), str(self.bare))
		self.requests = []
		self.prs = []
		self.lost_reply = False
		self.ignore_create = False
		self.close_race = False
		self.guard_held = False
		self.publication_guard_held = False
		self.guard_valid = True
		self.environment = mock.patch.dict(os.environ, {self.forge.TOKEN_ENV: "fixture_secret_never_log_1234"})
		self.environment.start()
		self.addCleanup(self.environment.stop)
		self.source_head = self.git(self.root, "rev-parse", "HEAD").stdout
		self.source_refs = self.git(self.root, "show-ref").stdout
		self.source_index = (self.root / ".git/index").read_bytes()

	@contextlib.contextmanager
	def publication_guard(self, config, binding):
		self.publication_guard_held = True
		try:
			yield {"writers_excluded": True, "offer_digest": binding.offer_digest,
				"target_commit": binding.target_commit, "head": config.head, "evidence_digest": "4" * 64}
		finally:
			self.publication_guard_held = False

	@contextlib.contextmanager
	def guard(self, config, binding, confirmation):
		self.assertEqual(config, self.config)
		self.assertEqual(binding.attempt_id, self.identity)
		self.assertEqual(confirmation["attempt_id"], self.identity)
		self.guard_held = True
		try:
			yield {"not_integrated": self.guard_valid, "writers_excluded": self.guard_valid,
				"offer_digest": binding.offer_digest, "target_commit": binding.target_commit,
				"evidence_digest": "3" * 64}
		finally:
			self.guard_held = False

	def remote_commit(self, branch):
		result = self.git(self.bare, "show-ref", "--verify", "--hash", "refs/heads/" + branch, check=False)
		return result.stdout.decode().strip() if result.returncode == 0 else None

	def repo(self):
		return {"id": 12, "full_name": "fixture/repo", "url": "https://api.github.com/repos/fixture/repo"}

	def http(self, method, host, endpoint, body, headers, timeout):
		self.assertTrue(self.publication_guard_held)
		self.assertEqual(host, "api.github.com")
		self.assertEqual(headers["Authorization"], "Bearer fixture_secret_never_log_1234")
		payload = json.loads(body) if body else None
		self.requests.append((method, endpoint, payload))
		prefix = "/repos/fixture/repo"
		status = 200
		if endpoint == prefix:
			value = self.repo()
		elif endpoint == "/user":
			value = {"id": 23, "login": "fixture-actor"}
		elif endpoint.startswith(prefix + "/git/ref/heads/"):
			branch = endpoint.split("/git/ref/heads/")[1]
			commit = self.remote_commit(branch)
			status = 200 if commit else 404
			value = {"ref": "refs/heads/" + branch, "url": "https://api.github.com" + prefix + "/git/refs/heads/" + branch,
				"object": {"type": "commit", "sha": commit}}
		elif endpoint.startswith(prefix + "/pulls?"):
			value = [{"number": entry["number"]} for entry in self.prs]
		elif method == "POST" and endpoint == prefix + "/pulls":
			self.assertEqual(payload["head"], self.config.head)
			self.assertEqual(payload["base"], self.config.base)
			self.assertIs(payload["maintainer_can_modify"], False)
			value = {"number": 1, "title": payload["title"], "body": payload["body"],
				"head": {"ref": self.config.head, "sha": self.remote_commit(self.config.head), "repo": self.repo()},
				"base": {"ref": self.config.base, "sha": self.target, "repo": self.repo()},
				"url": "https://api.github.com" + prefix + "/pulls/1",
				"html_url": "https://github.com/fixture/repo/pull/1", "state": "open", "merged": False}
			if not self.ignore_create:
				self.prs.append(value)
			if self.lost_reply:
				raise TimeoutError("fixture_secret_never_log_1234")
		elif endpoint == prefix + "/pulls/1":
			if method == "PATCH":
				if payload == {"state": "closed"}:
					self.assertTrue(self.guard_held)
				self.prs[0].update(payload)
				if self.close_race:
					self.prs[0].update(state="closed", merged=True)
			value = self.prs[0]
		else:
			self.fail("unexpected endpoint " + endpoint)
		return self.forge.HTTPResponse(status, json.dumps(value).encode(), host, endpoint)

	def runner(self, arguments, *, cwd, env, timeout):
		self.assertTrue(self.publication_guard_held)
		translated = list(arguments)
		if "push" in arguments:
			self.assertEqual(arguments[-2], "https://github.com/fixture/repo.git")
			self.assertRegex(arguments[-1], r"^[0-9a-f]{40}:refs/heads/cp-admission/hosted-attempt$")
			self.assertFalse(any("force" in item for item in arguments))
			translated[-2] = str(self.bare)
			translated[translated.index("protocol.https.allow=always")] = "protocol.file.allow=always"
		return self.forge.run_git(translated, cwd=cwd, env=env, timeout=timeout)

	def resume(self, **kwargs):
		return publication.resume_hosted(self.root, self.identity, True, kwargs.pop("owner", self.owner),
			http=self.http, git_runner=self.runner, **kwargs)

	def withdraw(self, **kwargs):
		return publication.withdraw_hosted(self.root, self.identity, {**self.confirmation, "attempt_id": self.identity},
			True, kwargs.pop("owner", self.owner), http=self.http, git_runner=self.runner, **kwargs)

	def authorization(self):
		return self.evidence.read_document(self.root, self.offered["offer"]["context_id"])[1].get("workflow", {}).get("admission", {})

	def assert_source_untouched(self):
		self.assertEqual(self.git(self.root, "rev-parse", "HEAD").stdout, self.source_head)
		self.assertEqual(self.git(self.root, "show-ref").stdout, self.source_refs)
		self.assertEqual((self.root / ".git/index").read_bytes(), self.source_index)

	def test_real_candidate_local_bare_lost_reply_retry_and_guarded_withdrawal(self):
		self.lost_reply = True
		result = self.resume()
		self.assertEqual(result["state"], "authorized-for-merge")
		self.assertEqual(self.authorization()["transport"], "github")
		self.assertFalse(self.authorization()["live_admission"])
		self.assertEqual(self.resume(), result)
		self.assertEqual(sum(method == "POST" for method, endpoint, body in self.requests), 1)
		self.assertEqual(len(self.authorization()["history"]), 1)
		self.assertEqual(self.remote_commit(self.config.head), result["commit"])
		self.assertEqual(self.remote_commit(self.config.base), self.target)
		self.assertEqual(self.git(self.bare, "rev-list", "--parents", "-n", "1", result["commit"]).stdout.decode().split(),
			[result["commit"], self.target])
		self.assert_source_untouched()
		events = publication.journal(self.root, self.directory)
		self.assertIn("hosted-confirmation", [event["state"] for event in events])
		self.assertIn("credential-observed", [event["state"] for event in events])
		self.assertNotIn("fixture_secret_never_log_1234", json.dumps(events))
		original_withdraw = publication.admission.withdraw
		def guarded(*args, **kwargs):
			self.assertTrue(self.guard_held)
			self.assertEqual(self.prs[0]["state"], "closed")
			return original_withdraw(*args, **kwargs)
		with mock.patch.object(publication.admission, "withdraw", side_effect=guarded):
			self.assertEqual(self.withdraw()["state"], "withdrawn")
		self.assertEqual(self.authorization()["status"], "withdrawn")
		self.assertEqual(self.withdraw()["state"], "withdrawn")
		with self.assertRaisesRegex(ValueError, "withdraw"):
			self.resume()
		self.assert_source_untouched()

	def test_disabled_or_changed_owner_precedes_transport(self):
		for owner in (self.forge.OwnerIntegration(), self.owner._replace(ci_evidence="f" * 64),
			self.owner._replace(authorize=lambda *args: False), self.owner._replace(publication_guard=None)):
			with self.subTest(owner=owner.owner), self.assertRaises(ValueError):
				self.resume(owner=owner)
		self.assertEqual(self.requests, [])
		self.assertEqual(self.authorization(), {})

	def test_config_confirmation_and_attempt_are_immutable(self):
		before = self.snapshot()
		with self.assertRaisesRegex(ValueError, "immutable publication record differs"):
			publication.create_attempt(self.root, self.offered, self.identity,
				{**self.confirmation, "rationale": "changed"}, True, owner=self.owner)
		self.assertEqual(self.snapshot(), before)
		changed = copy.deepcopy(self.offered)
		changed["offer"]["transport_config"]["repository_id"] = 99
		changed["offer_digest"] = self.contract.digest(changed["offer"])
		with self.assertRaisesRegex(ValueError, "immutable publication record differs"):
			publication.create_attempt(self.root, changed, self.identity,
				{**self.confirmation, "offer_digest": changed["offer_digest"]}, True, owner=self.owner)
		self.assertEqual(self.snapshot(), before)

	def test_cli_github_and_local_entry_points_fail_closed(self):
		for arguments in (("--transport", "github", "new-id"), ("new-id", "--transport", "github"),
			("resume", "--attempt", self.identity, "--confirmed")):
			with self.subTest(arguments=arguments), mock.patch.object(sys, "argv", [str(script_directory / "planning-publication.py"),
				"--root", str(self.root), *arguments]), contextlib.redirect_stderr(io.StringIO()) as output:
				self.assertEqual(publication.main(), 1)
				self.assertIn(self.forge.LIVE_BLOCKER, output.getvalue())
		for operation in (publication.close_request, publication.withdraw):
			with self.assertRaisesRegex(ValueError, self.forge.LIVE_BLOCKER):
				operation(self.root, self.identity, self.authority, True)
		with self.assertRaisesRegex(ValueError, self.forge.LIVE_BLOCKER):
			publication.create_attempt(self.root, self.offered, self.identity, self.confirmation, True)
		self.assertEqual(self.requests, [])
		self.assertEqual(self.authorization(), {})

	def test_missing_guard_preserves_authorization_without_closure(self):
		self.resume()
		before = copy.deepcopy(self.authorization())
		for owner in (self.owner._replace(withdrawal_guard=None), self.owner):
			self.guard_valid = False
			with self.assertRaisesRegex(ValueError, "guard"):
				self.withdraw(owner=owner)
			self.assertEqual(self.authorization(), before)
			self.assertEqual(self.prs[0]["state"], "open")

	def test_closed_and_merged_do_not_withdraw_or_prove_integration(self):
		self.resume()
		before = copy.deepcopy(self.authorization())
		self.prs[0]["state"] = "closed"
		self.assertEqual(self.resume()["state"], "closed-unmerged")
		self.prs[0]["merged"] = True
		self.assertEqual(self.resume()["state"], "merged-unverified")
		self.assertEqual(self.authorization(), before)
		with self.assertRaisesRegex(ValueError, "trusted verification"):
			self.withdraw()
		self.assertEqual(self.authorization(), before)

	def test_bound_candidate_validation_cost(self):
		root, directory, header = publication.load_attempt(self.root, self.identity)
		publication.candidate(root, directory, header)
		with mock.patch.object(publication, "check_candidate_contents", wraps=publication.check_candidate_contents) as checker, \
			 mock.patch.object(publication.planning_git, "git", wraps=self.git) as git:
			transport = publication.hosted_transport(root, directory, header, self.owner, http=self.http, git_runner=self.runner)
			prepared_checks = checker.call_count
			prepared_git = git.call_count
			with transport.session():
				for request in range(3):
					transport.api("GET", transport.prefix)
			print(f"BOUND_COST construction_checks={prepared_checks} construction_git={prepared_git} "
				f"later_checks={checker.call_count - prepared_checks} later_git={git.call_count - prepared_git} "
				f"requests={len(self.requests)}", flush=True)
			self.assertEqual(checker.call_count, prepared_checks)
			self.assertEqual(prepared_checks, 1)
			self.assertEqual(len(self.requests), 3)
			self.assertEqual(git.call_count - prepared_git, 28)
			publication.hosted_transport(root, directory, header, self.owner, http=self.http, git_runner=self.runner)
			self.assertEqual(checker.call_count, prepared_checks + 1)

	def test_warm_gate_refuses_changed_current_state_and_bundle(self):
		root, directory, header = publication.load_attempt(self.root, self.identity)
		transport = publication.hosted_transport(root, directory, header, self.owner, http=self.http, git_runner=self.runner)
		filename, document = self.evidence.read_document(root, header["offer"]["context_id"])
		original = filename.read_bytes()
		bundle_file = root / header["offer"]["bundle"] / "result.json"
		claim_file = publication.home(root) / "claims" / (document["id"] + ".json")
		with transport.session(), mock.patch.object(publication, "check_candidate_contents", wraps=publication.check_candidate_contents) as checker:
			transport.api("GET", transport.prefix)
			for field in ("source", "authorization", "findings", "decision", "transfer"):
				changed = copy.deepcopy(document)
				if field == "source":
					changed["proposal"]["revision"] += 1
				elif field == "authorization":
					changed["workflow"]["admission"] = {"status": "authorized-for-merge", "attempt_id": "other",
						"bundle_id": header["offer"]["bundle_id"]}
				elif field == "findings":
					self.evidence.record_round(changed, "SCRUB", "warm-gate", "New report", [{"summary": "New finding",
						"severity": "medium", "consequence": "Stale decision", "scope": "Fixture", "recommendation": "Review",
						"locations": ["fixture://source"]}],
						"Fixture Reviewer", "2026-09-29")
				elif field == "decision":
					changed["workflow"]["decision"]["current_id"] = "missing-decision"
				else:
					changed["context"] = {"state": "absorbed"}
				filename.write_text(self.capture.render(changed))
				requests = len(self.requests)
				try:
					with self.subTest(field=field), self.assertRaises(ValueError):
						transport.api("GET", transport.prefix)
					self.assertEqual(len(self.requests), requests)
				finally:
					filename.write_bytes(original)
			for changed_file in (bundle_file, claim_file):
				content = changed_file.read_bytes()
				changed_file.write_bytes(b"{}\n")
				requests = len(self.requests)
				try:
					with self.subTest(filename=changed_file.name), self.assertRaises(ValueError):
						transport.api("GET", transport.prefix)
					self.assertEqual(len(self.requests), requests)
				finally:
					changed_file.write_bytes(content)
			moved = self.git(root, "commit-tree", self.target + "^{tree}", "-p", self.target, "-m", "Moved fixture target").stdout.decode().strip()
			self.git(root, "update-ref", header["offer"]["target_ref"], moved)
			requests = len(self.requests)
			try:
				with self.assertRaises(ValueError):
					transport.api("GET", transport.prefix)
				self.assertEqual(len(self.requests), requests)
			finally:
				self.git(root, "update-ref", header["offer"]["target_ref"], self.target)
			files, paths = publication.expected_files(root, header)
			files[publication.admission.SPECIFICATION_PATH] += b" "
			with mock.patch.object(publication, "expected_files", return_value=(files, paths)), self.assertRaisesRegex(ValueError, "bound candidate bytes changed"):
				transport.api("GET", transport.prefix)
			self.assertEqual(len(self.requests), requests)
			transport.api("GET", transport.prefix)
			checker.assert_not_called()

	def test_warm_gate_refuses_git_replacements_and_grafts(self):
		root, directory, header = publication.load_attempt(self.root, self.identity)
		transport = publication.hosted_transport(root, directory, header, self.owner, http=self.http, git_runner=self.runner)
		with transport.session():
			transport.api("GET", transport.prefix)
			for repository in (root, transport.binding.sandbox):
				with self.subTest(repository=str(repository)):
					replacement = "refs/replace/" + self.target
					self.git(repository, "update-ref", replacement, self.target)
					self.git(repository, "pack-refs", "--all", "--prune")
					requests = len(self.requests)
					try:
						with self.assertRaisesRegex(ValueError, "replacement refs or grafts"):
							transport.api("GET", transport.prefix)
						self.assertEqual(len(self.requests), requests)
					finally:
						self.git(repository, "update-ref", "-d", replacement)
					grafts = repository / ".git/info/grafts"
					grafts.write_text(self.target + "\n")
					try:
						with self.assertRaisesRegex(ValueError, "replacement refs or grafts"):
							transport.api("GET", transport.prefix)
						self.assertEqual(len(self.requests), requests)
					finally:
						grafts.unlink()
			transport.api("GET", transport.prefix)

	def test_closure_race_preserves_capture_authorization(self):
		self.resume()
		before = copy.deepcopy(self.authorization())
		self.close_race = True
		with self.assertRaisesRegex(ValueError, "closure raced"):
			self.withdraw()
		self.assertEqual(self.authorization(), before)
		self.assertNotIn("withdrawn", [event["state"] for event in publication.journal(self.root, self.directory)])

	def test_create_intent_survives_restart_without_duplicate(self):
		self.ignore_create = True
		self.lost_reply = True
		for retry in range(2):
			with self.assertRaisesRegex(ValueError, "creation outcome uncertain"):
				self.resume()
		self.assertEqual(sum(method == "POST" for method, endpoint, body in self.requests), 1)
		self.assertEqual(self.authorization(), {})
		self.assert_source_untouched()

	def test_withdrawal_rejects_cross_call_request_substitution_before_patch(self):
		self.resume()
		before = copy.deepcopy(self.authorization())
		original = self.http
		def substituted(method, host, endpoint, *args):
			if "/pulls?" in endpoint:
				return self.forge.HTTPResponse(200, b'[{"number":2}]', host, endpoint)
			if endpoint.endswith("/pulls/2"):
				value = {**self.prs[0], "number": 2, "url": "https://api.github.com/repos/fixture/repo/pulls/2",
					"html_url": "https://github.com/fixture/repo/pull/2"}
				return self.forge.HTTPResponse(200, json.dumps(value).encode(), host, endpoint)
			return original(method, host, endpoint, *args)
		self.http = substituted
		with self.assertRaisesRegex(ValueError, "pinned request identity changed"):
			self.withdraw()
		self.assertEqual(self.authorization(), before)
		self.assertEqual(self.prs[0]["state"], "open")
		self.assertFalse(any(method == "PATCH" for method, endpoint, body in self.requests))

	def test_withdrawal_capture_success_journal_loss_recovers_with_new_guard(self):
		self.resume()
		append_event = publication.append_event
		def lose_event(root, directory, state, data):
			if state == "withdrawn":
				raise OSError("fixture journal write interruption")
			return append_event(root, directory, state, data)
		with mock.patch.object(publication, "append_event", side_effect=lose_event):
			with self.assertRaisesRegex(OSError, "interruption"):
				self.withdraw()
		before = copy.deepcopy(self.authorization())
		self.assertEqual(before["status"], "withdrawn")
		self.assertTrue((self.directory / "withdrawal-intent.json").is_file())
		context_id = self.offered["offer"]["context_id"]
		filename = self.capture.resolve_document(self.root, context_id)
		source = self.root / "after-withdrawal.txt"
		source.write_bytes(b"Legitimate source appended after capture unlock")
		self.capture.append_sources(self.root, context_id, self.evidence.retain(filename.read_bytes())["sha256"], [source], True)
		changed = filename.read_bytes()
		with self.assertRaisesRegex(ValueError, "withdrawal"):
			self.resume()
		@contextlib.contextmanager
		def refreshed_guard(config, binding, confirmation):
			with self.guard(config, binding, confirmation) as proof:
				yield {**proof, "evidence_digest": "5" * 64}
		self.assertEqual(self.withdraw(owner=self.owner._replace(withdrawal_guard=refreshed_guard))["state"], "withdrawn")
		self.assertEqual(self.authorization(), before)
		self.assertEqual(filename.read_bytes(), changed)
		self.assertEqual(len(before["history"]), 2)
		self.assertEqual(publication.journal(self.root, self.directory)[-1]["data"]["guard"]["evidence_digest"], "5" * 64)
		self.assertEqual(publication.journal(self.root, self.directory)[-1]["data"]["confirmation"],
			{**self.confirmation, "attempt_id": self.identity})
		self.create_next_attempt()

	def create_next_attempt(self):
		context_id = self.offered["offer"]["context_id"]
		filename, document = self.evidence.read_document(self.root, context_id)
		review_id = self.evidence.record_review(document, "review-next", self.evidence.subject(document), b"Fresh independent review",
			[], {**self.authority, "actor": "Independent Fixture Reviewer", "scope": "Complete fixture", "independent": True}, True)
		fields = {"kind": "approval", "actor": self.authority["actor"], "authority": self.authority["authority"],
			"date": self.authority["date"], "scope": "Complete fixture", "checklist": dict.fromkeys(self.contract.CHECK_NAMES, True),
			"integration_assessment": "Fixture only", "dag_assessment": "Empty DAG", "findings_acknowledged": [],
			"conditions": [], "signoff": "Synthetic fixture signoff", "invocation_source": "operator-confirmation"}
		digest = self.evidence.draft_decision(document, "decision-next", [review_id], fields)
		decision = document["workflow"]["decision"]["drafts"][-1]["decision"]
		self.evidence.finalize_decision(document, "decision-next", digest,
			{**self.authority, "decision_digest": self.contract.digest(decision)}, True, supersedes="decision-1")
		self.evidence.mutate(self.root, context_id, self.evidence.retain(filename.read_bytes())["sha256"], lambda current: document, True)
		bundle = publication.admission.prepare(self.root, context_id, "decision-next", self.base_path, self.execution_path,
			self.evidence.retain(filename.read_bytes())["sha256"], True)["bundle"]
		offered = publication.offer(self.root, bundle, "refs/heads/integration",
			github_config=self.config._replace(head="cp-admission/next-attempt"), owner=self.owner)
		result = publication.create_attempt(self.root, offered, "next-attempt",
			{**self.authority, "offer_digest": offered["offer_digest"]}, True, owner=self.owner)
		self.assertEqual(result["state"], "prepared")
		claim = self.contract.load_json(publication.home(self.root) / "claims" / (context_id + ".json"))
		self.assertEqual(claim["attempt_id"], "next-attempt")
		self.assert_source_untouched()

	def test_withdrawal_recovery_rejects_changed_capture_claim_and_confirmation(self):
		self.resume()
		append_event = publication.append_event
		def lose_event(root, directory, state, data):
			if state == "withdrawn":
				raise OSError("fixture journal write interruption")
			return append_event(root, directory, state, data)
		with mock.patch.object(publication, "append_event", side_effect=lose_event), self.assertRaises(OSError):
			self.withdraw()
		filename, document = self.evidence.read_document(self.root, self.offered["offer"]["context_id"])
		original = filename.read_bytes()
		requests = len(self.requests)
		for field in ("withdrawal", "history", "request_id", "attempt_id"):
			changed = copy.deepcopy(document)
			active = changed["workflow"]["admission"]
			if field == "withdrawal":
				active[field]["rationale"] = "changed"
			elif field == "history":
				active[field] = active[field][:-1]
			else:
				active[field] += "changed"
			filename.write_text(self.capture.render(changed))
			with self.subTest(field=field), self.assertRaises(ValueError):
				self.withdraw()
			self.assertEqual(len(self.requests), requests)
		filename.write_bytes(original)
		with self.assertRaisesRegex(ValueError, "changed confirmation"):
			publication.withdraw_hosted(self.root, self.identity,
				{**self.confirmation, "attempt_id": self.identity, "rationale": "changed"}, True,
				self.owner, http=self.http, git_runner=self.runner)
		self.assertEqual(len(self.requests), requests)

	def test_cancel_prepared_never_published_then_new_attempt(self):
		remote_refs = self.git(self.bare, "show-ref").stdout
		result = self.withdraw()
		self.assertEqual(result["state"], "withdrawn")
		self.assertEqual(result["events"][-1]["data"]["closure"]["state"], "cancelled-unpublished")
		self.assertEqual(self.authorization(), {})
		self.assertTrue(self.requests)
		self.assertTrue(all(method == "GET" for method, endpoint, body in self.requests))
		self.assertEqual(self.git(self.bare, "show-ref").stdout, remote_refs)
		self.assertEqual(self.withdraw()["state"], "withdrawn")
		with self.assertRaisesRegex(ValueError, "withdrawal"):
			self.resume()
		self.create_next_attempt()

	def test_cancel_prepared_after_source_append_then_refreshed_attempt(self):
		context_id = self.offered["offer"]["context_id"]
		filename, document = self.evidence.read_document(self.root, context_id)
		original_proposal = copy.deepcopy(document["proposal"])
		source = self.root / "before-cancellation.txt"
		source.write_bytes(b"Legitimate new source before unpublished cancellation")
		self.capture.append_sources(self.root, context_id, self.evidence.retain(filename.read_bytes())["sha256"], [source], True)
		changed = filename.read_bytes()
		document = self.capture.read_capture(filename)
		self.assertNotEqual(document["proposal"], original_proposal)
		self.assertEqual(self.authorization(), {})
		remote_refs = self.git(self.bare, "show-ref").stdout
		guard = mock.Mock(wraps=self.owner.withdrawal_guard)
		with mock.patch.object(self, "runner", wraps=self.runner) as runner:
			result = self.withdraw(owner=self.owner._replace(withdrawal_guard=guard))
			guard.assert_called_once()
			self.assertEqual(result["state"], "withdrawn")
			self.assertEqual(result["events"][-1]["data"]["closure"]["state"], "cancelled-unpublished")
			self.assertEqual(filename.read_bytes(), changed)
			self.assertEqual(self.authorization(), {})
			self.assertTrue(self.requests)
			self.assertTrue(all(method == "GET" for method, endpoint, body in self.requests))
			endpoints = [endpoint for method, endpoint, body in self.requests]
			for endpoint in ("/repos/fixture/repo", "/repos/fixture/repo/git/ref/heads/" + self.config.base,
				"/repos/fixture/repo/git/ref/heads/" + self.config.head):
				self.assertIn(endpoint, endpoints)
			self.assertTrue(any("/pulls?" in endpoint and "state=all" in endpoint for endpoint in endpoints))
			before = self.snapshot()
			requests = len(self.requests)
			self.assertEqual(self.withdraw(), result)
			self.assertEqual(self.snapshot(), before)
			self.create_next_attempt()
			refreshed = self.capture.read_capture(filename)
			self.assertEqual(refreshed["sources"], document["sources"])
			self.assertEqual(refreshed["proposal"], document["proposal"])
			self.assertEqual(self.authorization(), {})
			before = self.snapshot()
			self.assertEqual(self.withdraw(), result)
			with self.assertRaisesRegex(ValueError, "withdrawal"):
				self.resume()
			self.assertEqual(self.snapshot(), before)
			self.assertEqual(len(self.requests), requests)
			self.assertEqual(runner.call_count, 0)
		self.assertEqual(sum(method == "POST" for method, endpoint, body in self.requests), 0)
		self.assertEqual(sum(method == "PATCH" for method, endpoint, body in self.requests), 0)
		self.assertEqual(self.git(self.bare, "show-ref").stdout, remote_refs)
		self.assert_source_untouched()

	def test_cancel_uncertain_post_refused_even_when_remote_absent(self):
		self.ignore_create = True
		self.lost_reply = True
		with self.assertRaisesRegex(ValueError, "creation outcome uncertain"):
			self.resume()
		self.git(self.bare, "update-ref", "-d", "refs/heads/" + self.config.head)
		before = self.snapshot()
		requests = len(self.requests)
		with self.assertRaisesRegex(ValueError, "mutating publication intent"):
			self.withdraw()
		self.assertEqual(self.snapshot(), before)
		self.assertEqual(len(self.requests), requests)
		self.assertEqual(sum(method == "POST" for method, endpoint, body in self.requests), 1)
		offered = publication.offer(self.root, self.offered["offer"]["bundle"], "refs/heads/integration",
			github_config=self.config._replace(head="cp-admission/next-attempt"), owner=self.owner)
		with self.assertRaisesRegex(ValueError, "competing publication attempt"):
			publication.create_attempt(self.root, offered, "next-attempt",
				{**self.authority, "offer_digest": offered["offer_digest"]}, True, owner=self.owner)
		self.assert_source_untouched()

	def test_cancel_preserves_existing_branch_and_requires_guard(self):
		self.guard_valid = False
		with self.assertRaisesRegex(ValueError, "guard refused"):
			self.withdraw()
		self.assertEqual(self.requests, [])
		self.guard_valid = True
		self.git(self.bare, "update-ref", "refs/heads/" + self.config.head, self.target)
		remote_refs = self.git(self.bare, "show-ref").stdout
		with self.assertRaisesRegex(ValueError, "remote head moved"):
			self.withdraw()
		self.assertEqual(self.git(self.bare, "show-ref").stdout, remote_refs)
		self.assertTrue(all(method == "GET" for method, endpoint, body in self.requests))
		self.assertNotIn("withdrawn", [event["state"] for event in publication.journal(self.root, self.directory)])


unittest.main(verbosity=2, defaultTest=os.environ.get("PLANNING_PUBLICATION_TEST_FILTER"))
PY