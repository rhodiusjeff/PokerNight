#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/../../.." && pwd -P)"
python3 - "$ROOT" <<'PY'
import json
import base64
import copy
import hashlib
import importlib.util
import pathlib
import subprocess
import sys
import tempfile
import unittest

root = pathlib.Path(sys.argv.pop())
script = root / "control-plane/framework/scripts/planning-git.py"
module_spec = importlib.util.spec_from_file_location("planning_contract", script.with_name("planning-contract.py"))
contract = importlib.util.module_from_spec(module_spec)
module_spec.loader.exec_module(contract)


class MergeTests(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory()
        self.addCleanup(self.temporary.cleanup)
        self.folder = pathlib.Path(self.temporary.name)
        self.remote = self.folder / "remote.git"
        self.repository = self.folder / "repository"
        subprocess.run(["git", "init", "--bare", "--quiet", str(self.remote)], check=True)
        subprocess.run(["git", "init", "--quiet", "-b", "main", str(self.repository)], check=True)
        self.git("config", "user.name", "Fixture")
        self.git("config", "user.email", "fixture@example.invalid")
        self.git("config", "commit.gpgSign", "false")
        self.git("config", "core.hooksPath", "/dev/null")
        (self.repository / "plan.md").write_text("Initial requirement\n")
        self.commit("seed")
        self.git("remote", "add", "origin", str(self.remote))
        self.git("push", "--quiet", "origin", "main")
        self.git("switch", "--quiet", "-c", "proposal")

    def git(self, *arguments, check=True):
        return subprocess.run(["git", "-C", str(self.repository), *arguments], check=check,
                              text=True, capture_output=True)

    def commit(self, message):
        self.git("add", ".")
        self.git("commit", "--quiet", "-m", message)

    def inspect(self, paths=None):
        arguments = []
        for name, filename in (paths or {}).items():
            arguments.extend(["--" + name + "-path", filename])
        result = subprocess.run([sys.executable, str(script), "--root", str(self.repository),
                                 "--proposal-ref", "refs/heads/proposal", "--target-ref", "refs/heads/main", *arguments],
                                capture_output=True, text=True)
        self.assertIn(result.returncode, (0, 2), result.stdout + result.stderr)
        return json.loads(result.stdout)

    def make_conflict(self):
        (self.repository / "plan.md").write_text("Proposal decision\n")
        self.commit("proposal decision")
        self.git("switch", "--quiet", "main")
        (self.repository / "plan.md").write_text("Target decision\n")
        self.commit("target decision")
        self.git("switch", "--quiet", "proposal")

    def admission(self):
        base = contract.empty_specification()
        execution = {"phases": {}, "contracts": {}}
        paths = {name: f"admission/{name}.json" for name in ("specification", "proposal", "reviews", "decision", "execution")}
        self.git("switch", "--quiet", "main")
        (self.repository / "admission").mkdir()
        self.write_json(paths["specification"], base)
        self.write_json(paths["execution"], execution)
        self.commit("empty operational fixture")
        self.git("branch", "-f", "proposal", "HEAD")
        self.git("switch", "--quiet", "proposal")
        value = {"kind": "requirement", "text": "Fixture requirement", "status": "active", "sources": ["brief"]}
        content = {"canon": {"REQ-1": value}, "phases": {}, "dag": {"order": [], "edges": []}}
        proposal = {"schema": "cp-plan-proposal-v1", "id": "PLAN-1", "revision": 1, "author": "fixture-author",
                    "base_revision": 0, "base_digest": base["content_digest"],
                    "sources": [{"id": "brief", "origin": "fixture", "sha256": hashlib.sha256(b"source").hexdigest(),
                                 "bytes_base64": base64.b64encode(b"source").decode()}],
                    "changes": [{"collection": "canon", "id": "REQ-1", "operation": "add", "before_digest": None, "value": value}],
                    "result": content, "execution_expectations": {}}
        reviews = [{"id": "REVIEW-1", "subject_digest": contract.digest(proposal), "reviewer": "fixture-reviewer",
                    "independent": True, "scope": "fixture", "report": "Synthetic review", "findings": []}]
        decision = {"schema": "cp-plan-decision-v1", "kind": "approval", "actor": "fixture-operator", "authority": "test-only",
                    "date": "2026-09-28", "scope": "fixture", "subject_digest": contract.digest(proposal),
                    "reviews_digest": contract.digest(reviews), "checklist": {name: True for name in contract.CHECK_NAMES},
                    "integration_assessment": "fixture", "dag_assessment": "fixture", "findings_acknowledged": [],
                    "conditions": [], "signoff": "Synthetic fixture only", "invocation_source": "operator-confirmation"}
        candidate = contract.validate_admission(base, proposal, reviews, decision, execution)["result"]
        for name, value in (("specification", candidate), ("proposal", proposal), ("reviews", reviews), ("decision", decision)):
            self.write_json(paths[name], value)
        self.commit("admission proposal fixture")
        return paths, candidate

    def write_json(self, filename, value):
        (self.repository / filename).write_text(json.dumps(value, indent=2) + "\n")

    def recovery(self, action, *arguments):
        result = subprocess.run([sys.executable, str(script), "--root", str(self.repository),
                                 "--action", action, *arguments], text=True, capture_output=True)
        return result, json.loads(result.stdout)

    def offer(self):
        result, offered = self.recovery("offer", "--proposal-ref", "refs/heads/proposal", "--target-ref", "refs/heads/main")
        self.assertIn(result.returncode, (0, 2), result.stderr)
        self.assertIn("offer_id", offered, offered)
        return offered

    def start(self, offered, confirmed=True):
        arguments = ["--proposal-ref", "refs/heads/proposal", "--target-ref", "refs/heads/main", "--offer-id", offered["offer_id"]]
        if confirmed:
            arguments.append("--confirmed")
        return self.recovery("start", *arguments)

    def test_real_text_conflict_preserves_worktree(self):
        self.make_conflict()
        before = self.git("show-ref").stdout
        original = (self.repository / "plan.md").read_bytes()
        result = self.inspect()
        self.assertEqual(result["status"], "text-conflict")
        self.assertEqual(result["conflicted_paths"], ["plan.md"])
        self.assertEqual(self.git("show-ref").stdout, before)
        self.assertEqual((self.repository / "plan.md").read_bytes(), original)
        self.assertEqual(self.git("status", "--porcelain").stdout, "")

    def test_clean_candidate_and_unrelated_target_movement(self):
        (self.repository / "proposal.md").write_text("Proposed change\n")
        self.commit("proposal")
        self.git("switch", "--quiet", "main")
        (self.repository / "implementation.txt").write_text("Unrelated implementation\n")
        self.commit("unrelated target change")
        result = self.inspect()
        self.assertEqual(result["status"], "merge-clean")
        self.assertEqual(result["conflicted_paths"], [])
        self.assertEqual(result["candidate_diff"], ["A", "proposal.md"])
        self.assertFalse(result["live_admission"])

    def test_dirty_work_is_preserved_and_reported(self):
        self.make_conflict()
        (self.repository / "unrelated.txt").write_bytes(b"Uncommitted\r\n")
        result = self.inspect()
        self.assertIn("?? unrelated.txt", result["dirty_work"])
        self.assertEqual((self.repository / "unrelated.txt").read_bytes(), b"Uncommitted\r\n")

    def test_existing_merge_is_not_taken_over(self):
        self.make_conflict()
        self.git("merge", "--no-commit", "main", check=False)
        before = (self.repository / ".git/MERGE_HEAD").read_bytes()
        result = self.inspect()
        self.assertEqual(result["status"], "operation-in-progress")
        self.assertEqual((self.repository / ".git/MERGE_HEAD").read_bytes(), before)

    def test_space_and_newline_conflict_paths(self):
        filename = self.repository / "odd name\nfile.md"
        filename.write_text("base\n")
        self.commit("new file")
        self.git("branch", "-f", "main", "HEAD")
        filename.write_text("proposal\n")
        self.commit("proposal update")
        self.git("switch", "--quiet", "main")
        filename.write_text("target\n")
        self.commit("target update")
        result = self.inspect()
        self.assertEqual(result["conflicted_paths"], ["odd name\nfile.md"])

    def test_actual_merge_candidate_passes_semantic_validation(self):
        paths, candidate = self.admission()
        self.git("switch", "--quiet", "main")
        (self.repository / "code.txt").write_text("Unrelated target work\n")
        self.commit("target implementation")
        result = self.inspect(paths)
        self.assertEqual(result["status"], "candidate-valid", result)
        self.assertEqual(result["content_digest"], candidate["content_digest"])

    def test_clean_git_merge_can_have_stale_operational_base(self):
        paths, candidate = self.admission()
        self.write_json(paths["specification"], contract.empty_specification())
        self.commit("retain proposal evidence without a conflicting specification edit")
        self.git("switch", "--quiet", "main")
        parallel = copy.deepcopy(candidate)
        parallel["admissions"][0]["proposal_id"] = "OTHER-PLAN"
        self.write_json(paths["specification"], parallel)
        self.commit("other admission with identical specification")
        self.assertEqual(self.inspect()["status"], "merge-clean")
        self.assertEqual(self.inspect(paths)["status"], "stale-base")

    def test_unmerged_parent_code_is_not_admission_content(self):
        paths, candidate = self.admission()
        (self.repository / "unreviewed-code.py").write_text("print('fixture')\n")
        self.commit("unintended parent implementation")
        result = self.inspect(paths)
        self.assertEqual(result["status"], "unexpected-changes")
        self.assertEqual(result["unexpected_paths"], ["unreviewed-code.py"])

    def test_offer_and_defer_do_not_write(self):
        self.make_conflict()
        before = self.git("status", "--porcelain").stdout
        offered = self.offer()
        result, refused = self.start(offered, confirmed=False)
        self.assertEqual(result.returncode, 1)
        self.assertIn("explicit confirmation", refused["message"])
        result, deferred = self.recovery("defer")
        self.assertEqual(result.returncode, 0)
        self.assertEqual(deferred["status"], "deferred")
        self.assertFalse((self.repository / "control-plane").exists())
        self.assertEqual(self.git("status", "--porcelain").stdout, before)

    def test_isolated_resolution_continues_without_touching_source(self):
        self.make_conflict()
        (self.repository / "dirty.txt").write_bytes(b"keep\r\n")
        refs = self.git("show-ref").stdout
        offered = self.offer()
        result, started = self.start(offered)
        self.assertEqual(started["status"], "conflicted", started)
        sandbox = pathlib.Path(started["worktree"])
        (sandbox / "plan.md").write_text("Explicit fixture resolution\n")
        subprocess.run(["git", "-C", str(sandbox), "add", "--", "plan.md"], check=True)
        result, current = self.recovery("status", "--offer-id", offered["offer_id"])
        result, finished = self.recovery("continue", "--offer-id", offered["offer_id"],
                                         "--resolution-digest", current["resolution_digest"], "--confirmed")
        self.assertEqual(result.returncode, 0, finished)
        self.assertEqual(finished["status"], "needs-revalidation")
        self.assertIsNone(finished["operation"])
        self.assertEqual(self.git("show-ref").stdout, refs)
        self.assertEqual((self.repository / "dirty.txt").read_bytes(), b"keep\r\n")
        self.assertEqual((self.repository / "plan.md").read_text(), "Proposal decision\n")
        self.assertTrue(list(sandbox.parent.glob("resolution-*.json")))

    def test_abort_restores_original_and_retains_resolution(self):
        self.make_conflict()
        offered = self.offer()
        result, started = self.start(offered)
        sandbox = pathlib.Path(started["worktree"])
        (sandbox / "plan.md").write_text("Unfinished fixture resolution\n")
        result, current = self.recovery("status", "--offer-id", offered["offer_id"])
        result, aborted = self.recovery("abort", "--offer-id", offered["offer_id"],
                                        "--resolution-digest", current["resolution_digest"], "--confirmed")
        self.assertEqual(result.returncode, 0, aborted)
        self.assertEqual(aborted["status"], "aborted")
        self.assertEqual((sandbox / "plan.md").read_text(), "Proposal decision\n")
        self.assertTrue(list(sandbox.parent.glob("resolution-*.json")))

    def test_changed_target_invalidates_offer(self):
        self.make_conflict()
        offered = self.offer()
        self.git("switch", "--quiet", "main")
        (self.repository / "later.md").write_text("Target moved\n")
        self.commit("later target")
        result, refused = self.start(offered)
        self.assertEqual(result.returncode, 1)
        self.assertIn("offer changed", refused["message"])
        self.assertFalse((self.repository / "control-plane").exists())

    def test_repeated_start_recovers_same_conflicted_session(self):
        self.make_conflict()
        offered = self.offer()
        result, first = self.start(offered)
        result, repeated = self.start(offered)
        self.assertEqual(repeated["status"], "conflicted")
        self.assertEqual(first["worktree"], repeated["worktree"])
        self.assertEqual(first["resolution_digest"], repeated["resolution_digest"])


unittest.main(verbosity=2)
PY